﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsteWebpage
{

    public class StudyAbroad
    {

        public String title { get; set; }
        public String description { get; set; }
        public List<places> places { get; set; }




    }
    public class places
    {

        public String nameOfPlace { get; set; }
        public String description { get; set; }


    }
    public class StudentServices
    {

        public string title { get; set; }
        public academicAdvisors academicAdvisors{get;set;}
        public istMinorAdvising istMinorAdvising{get;set;}
        public facultyAdvisors facultyAdvisors{get;set;}
        public professonalAdvisors professonalAdvisors{ get; set; }


    }
    public class professonalAdvisors
    {


        public string title { get; set; }

        public List<advisorInformation> advisorInformation { get; set; }


    }
    public class advisorInformation
    {

        public string name { get; set; }
        public string department { get; set; }
        public string email { get; set; }


    }

    public class academicAdvisors
    {

        public string title{get; set;}
        public string description{get;set;}
        public faq faq{get;set;}



    }
    public class faq
    {
        public string title{get;set;}
        public string contentHref{get;set;}



    }
    public class facultyAdvisors
    {
        public string title{get;set;}
        public string description{get;set;}




    }
    public class istMinorAdvising
    {

        public string title{get;set;}
        
        public List<minorAdvisorInformation>minorAdvisorInformation{get;set;}


    }
    public class minorAdvisorInformation
    {

        public string title{get;set;}
        public string advisor{get;set;}
        public string email{get;set;}


    }
    public class StudentAmbassadors
    {

        public string title{get;set;}
        public string ambassadorsImageSource{get;set;}
        public string applicationFormLink{get;set;}
        public string note{get;set;}
        public List<subSectionContent> subSectionContent{get;set;}


    }
    public class subSectionContent
    {
        public string title{get;set;}
        public string description{get;set;}

    }
    public class Forms
    {

        public List<graduateForms> graduateForms{get;set;}
        public List<undergraduateForms> undergraduateForms{get;set;}


    }
    public class graduateForms
    {

        public string formName{get;set;}
        public string href{get;set;}


    }
     public class undergraduateForms
    {

        public string formName {get;set;}
        public string href {get;set;}


    }
     public class coopEnrollment
    {

        public string title{get;set;}
        public List<enrollmentInformationContent> enrollmentInformationContent { get; set; }
        public string RITJobZoneGuidelink { get; set; }


    }
     public class enrollmentInformationContent
    {
         public string title{get;set;}
         public string description{get;set;}


    }
    public class tutorsAndLabInformation
    {
        public string title { get; set; }
        public string description { get; set; }
        public string tutoringLabHoursLink { get; set; }


    }
    public class resources
    {
        public String title { get; set; }
        public String subTitle { get; set; }
        public StudyAbroad studyAbroad { get; set; }
        public StudentServices studentServices { get; set; }
        public StudentAmbassadors studentAmbassadors{get;set;}
        public Forms forms{get;set;}
        public coopEnrollment coopEnrollment { get; set; }
        public tutorsAndLabInformation tutorsAndLabInformation { get; set; }



    }
}

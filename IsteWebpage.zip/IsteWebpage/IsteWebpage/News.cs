﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsteWebpage
{
    public class year
    {
        public string date{ get; set;}
        public string title{get; set;}
        public string description { get; set; }



    }
    public class older
    {
        public string date { get; set; }
        public string title { get; set; }
        public string description { get; set; }



    }
    public class quarter
    {
        public string date { get; set; }
        public string title { get; set; }
        public string description { get; set; }

    }
    public class month
    {
        public string date { get; set; }
        public string title { get; set; }
        public string description { get; set; }

    }


   public class News
    {
      
       public List<year> year { get; set; }
       public List<month> month { get; set; }
       public List<older> older { get; set; }
       public List<quarter> quarter { get; set; }

    }
}

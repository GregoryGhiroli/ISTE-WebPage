﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsteWebpage
{

    public class social
    {
        public string title { get; set; }
        public string tweet { get; set; }
        public string by { get; set; }
        public string twitter { get; set; }
        public string facebook { get; set; }



    }
    public class quickLinks
    {

        public string title { get; set; }
        public string href { get; set; }


   }
    public class copyright
    {
        public string title { get; set; }
        public string html { get; set; }
    }


    public class Footer
    {
        public string news { get; set; }
        public List<quickLinks> quickLinks { get; set; }
        public social social { get; set; }
        public copyright copyright { get; set; }

    }
}

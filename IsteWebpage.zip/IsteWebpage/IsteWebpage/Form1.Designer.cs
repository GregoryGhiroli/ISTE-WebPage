﻿namespace IsteWebpage
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
               
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.QuickLinks = new System.Windows.Forms.TabPage();
            this.panel32 = new System.Windows.Forms.Panel();
            this.richTextBox21 = new System.Windows.Forms.RichTextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.dataGridView58 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.dataGridView29 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView30 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.dataGridView31 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView32 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.dataGridView27 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView28 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.dataGridView25 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView26 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.dataGridView23 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView24 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.dataGridView22 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView21 = new System.Windows.Forms.DataGridView();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label79 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.label112 = new System.Windows.Forms.Label();
            this.dataGridView44 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label113 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.dataGridView43 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label111 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.dataGridView42 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label109 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.dataGridView41 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label107 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.dataGridView40 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label105 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.dataGridView39 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label103 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.dataGridView38 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label101 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.dataGridView37 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label99 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.dataGridView36 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label97 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.dataGridView35 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label95 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.dataGridView34 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label93 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.dataGridView33 = new System.Windows.Forms.DataGridView();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label90 = new System.Windows.Forms.Label();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.label114 = new System.Windows.Forms.Label();
            this.dataGridView45 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.dataGridView46 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.dataGridView47 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.dataGridView48 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.dataGridView49 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.dataGridView50 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.dataGridView51 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.dataGridView52 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label129 = new System.Windows.Forms.Label();
            this.tabePage10 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.panel19 = new System.Windows.Forms.Panel();
            this.richTextBox24 = new System.Windows.Forms.RichTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox15 = new System.Windows.Forms.RichTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.richTextBox23 = new System.Windows.Forms.RichTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox14 = new System.Windows.Forms.RichTextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.richTextBox22 = new System.Windows.Forms.RichTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.panel22 = new System.Windows.Forms.Panel();
            this.richTextBox26 = new System.Windows.Forms.RichTextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox18 = new System.Windows.Forms.RichTextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox17 = new System.Windows.Forms.RichTextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.richTextBox25 = new System.Windows.Forms.RichTextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox16 = new System.Windows.Forms.RichTextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.panel24 = new System.Windows.Forms.Panel();
            this.richTextBox27 = new System.Windows.Forms.RichTextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.dataGridView12 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox20 = new System.Windows.Forms.RichTextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.richTextBox28 = new System.Windows.Forms.RichTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.richTextBox19 = new System.Windows.Forms.RichTextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.webBrowser2 = new System.Windows.Forms.WebBrowser();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl7 = new System.Windows.Forms.TabControl();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.richTextBox34 = new System.Windows.Forms.RichTextBox();
            this.label133 = new System.Windows.Forms.Label();
            this.dataGridView53 = new System.Windows.Forms.DataGridView();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.tabControl8 = new System.Windows.Forms.TabControl();
            this.tabPage34 = new System.Windows.Forms.TabPage();
            this.dataGridView54 = new System.Windows.Forms.DataGridView();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label134 = new System.Windows.Forms.Label();
            this.tabPage35 = new System.Windows.Forms.TabPage();
            this.richTextBox35 = new System.Windows.Forms.RichTextBox();
            this.label135 = new System.Windows.Forms.Label();
            this.tabPage36 = new System.Windows.Forms.TabPage();
            this.dataGridView55 = new System.Windows.Forms.DataGridView();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label136 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.richTextBox36 = new System.Windows.Forms.RichTextBox();
            this.label138 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.tabPage31 = new System.Windows.Forms.TabPage();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label141 = new System.Windows.Forms.Label();
            this.dataGridView56 = new System.Windows.Forms.DataGridView();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label140 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.tabPage32 = new System.Windows.Forms.TabPage();
            this.label145 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.dataGridView57 = new System.Windows.Forms.DataGridView();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage33 = new System.Windows.Forms.TabPage();
            this.panel31 = new System.Windows.Forms.Panel();
            this.richTextBox40 = new System.Windows.Forms.RichTextBox();
            this.label149 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.richTextBox39 = new System.Windows.Forms.RichTextBox();
            this.label148 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.richTextBox38 = new System.Windows.Forms.RichTextBox();
            this.label147 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.richTextBox37 = new System.Windows.Forms.RichTextBox();
            this.label146 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.panel26 = new System.Windows.Forms.Panel();
            this.richTextBox29 = new System.Windows.Forms.RichTextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label58 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.panel27 = new System.Windows.Forms.Panel();
            this.richTextBox30 = new System.Windows.Forms.RichTextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Employer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Degree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.City = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Term = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dataGridView16 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label25 = new System.Windows.Forms.Label();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dataGridView15 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label24 = new System.Windows.Forms.Label();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dataGridView14 = new System.Windows.Forms.DataGridView();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label23 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridView17 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView19 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label15 = new System.Windows.Forms.Label();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.dataGridView18 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label17 = new System.Windows.Forms.Label();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.richTextBox13 = new System.Windows.Forms.RichTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.richTextBox12 = new System.Windows.Forms.RichTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.panel17 = new System.Windows.Forms.Panel();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label33 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.QuickLinks.SuspendLayout();
            this.panel32.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView58)).BeginInit();
            this.tabPage24.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).BeginInit();
            this.tabPage26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView33)).BeginInit();
            this.tabPage27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView52)).BeginInit();
            this.tabePage10.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage14.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            this.panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.tabPage15.SuspendLayout();
            this.panel24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).BeginInit();
            this.panel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl7.SuspendLayout();
            this.tabPage28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView53)).BeginInit();
            this.tabPage29.SuspendLayout();
            this.tabControl8.SuspendLayout();
            this.tabPage34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView54)).BeginInit();
            this.tabPage35.SuspendLayout();
            this.tabPage36.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView55)).BeginInit();
            this.tabPage30.SuspendLayout();
            this.tabPage31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView56)).BeginInit();
            this.tabPage32.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView57)).BeginInit();
            this.tabPage33.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel28.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.panel26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.tabPage18.SuspendLayout();
            this.panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.tabPage10.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).BeginInit();
            this.panel11.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = global::IsteWebpage.Properties.Resources.idbar;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1442, 112);
            this.panel1.TabIndex = 0;
            // 
          
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // QuickLinks
            // 
            this.QuickLinks.BackgroundImage = global::IsteWebpage.Properties.Resources.current_minors_immersions;
            this.QuickLinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.QuickLinks.Controls.Add(this.panel32);
            this.QuickLinks.Location = new System.Drawing.Point(4, 22);
            this.QuickLinks.Name = "QuickLinks";
            this.QuickLinks.Size = new System.Drawing.Size(1329, 936);
            this.QuickLinks.TabIndex = 11;
            this.QuickLinks.Text = "QuickLinks";
            this.QuickLinks.UseVisualStyleBackColor = true;
            // 
            // panel32
            // 
            this.panel32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel32.BackColor = System.Drawing.Color.MediumOrchid;
            this.panel32.Controls.Add(this.richTextBox21);
            this.panel32.Controls.Add(this.label50);
            this.panel32.Controls.Add(this.label156);
            this.panel32.Controls.Add(this.label157);
            this.panel32.Controls.Add(this.label154);
            this.panel32.Controls.Add(this.label155);
            this.panel32.Controls.Add(this.label153);
            this.panel32.Controls.Add(this.label152);
            this.panel32.Controls.Add(this.dataGridView58);
            this.panel32.Location = new System.Drawing.Point(3, 51);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(1322, 794);
            this.panel32.TabIndex = 3;
            // 
            // richTextBox21
            // 
            this.richTextBox21.Location = new System.Drawing.Point(25, 637);
            this.richTextBox21.Name = "richTextBox21";
            this.richTextBox21.Size = new System.Drawing.Size(1278, 68);
            this.richTextBox21.TabIndex = 18;
            this.richTextBox21.Text = "";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Black;
            this.label50.ForeColor = System.Drawing.Color.Linen;
            this.label50.Location = new System.Drawing.Point(22, 724);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(68, 18);
            this.label50.TabIndex = 17;
            this.label50.Text = "label50";
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.BackColor = System.Drawing.Color.Black;
            this.label156.ForeColor = System.Drawing.Color.Linen;
            this.label156.Location = new System.Drawing.Point(22, 555);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(78, 18);
            this.label156.TabIndex = 15;
            this.label156.Text = "label156";
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.BackColor = System.Drawing.Color.Black;
            this.label157.ForeColor = System.Drawing.Color.Linen;
            this.label157.Location = new System.Drawing.Point(22, 607);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(78, 18);
            this.label157.TabIndex = 14;
            this.label157.Text = "label157";
            this.label157.Click += new System.EventHandler(this.label157_Click);
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.BackColor = System.Drawing.Color.Black;
            this.label154.ForeColor = System.Drawing.Color.Linen;
            this.label154.Location = new System.Drawing.Point(22, 416);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(78, 18);
            this.label154.TabIndex = 13;
            this.label154.Text = "label154";
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.BackColor = System.Drawing.Color.Black;
            this.label155.ForeColor = System.Drawing.Color.Linen;
            this.label155.Location = new System.Drawing.Point(22, 521);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(78, 18);
            this.label155.TabIndex = 12;
            this.label155.Text = "label155";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.BackColor = System.Drawing.Color.Black;
            this.label153.ForeColor = System.Drawing.Color.Linen;
            this.label153.Location = new System.Drawing.Point(22, 451);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(78, 18);
            this.label153.TabIndex = 11;
            this.label153.Text = "label153";
            this.label153.Click += new System.EventHandler(this.label153_Click);
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.BackColor = System.Drawing.Color.Black;
            this.label152.ForeColor = System.Drawing.Color.Linen;
            this.label152.Location = new System.Drawing.Point(22, 489);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(78, 18);
            this.label152.TabIndex = 10;
            this.label152.Text = "label152";
            // 
            // dataGridView58
            // 
            this.dataGridView58.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView58.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45});
            this.dataGridView58.Location = new System.Drawing.Point(25, 187);
            this.dataGridView58.Name = "dataGridView58";
            this.dataGridView58.Size = new System.Drawing.Size(1294, 212);
            this.dataGridView58.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.FillWeight = 200F;
            this.dataGridViewTextBoxColumn44.HeaderText = "title";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.Width = 200;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.FillWeight = 5000F;
            this.dataGridViewTextBoxColumn45.HeaderText = "Href";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            this.dataGridViewTextBoxColumn45.Width = 5000;
            // 
            // tabPage24
            // 
            this.tabPage24.BackColor = System.Drawing.Color.Black;
            this.tabPage24.Controls.Add(this.tabControl6);
            this.tabPage24.Location = new System.Drawing.Point(4, 22);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Size = new System.Drawing.Size(1329, 936);
            this.tabPage24.TabIndex = 10;
            this.tabPage24.Text = "Research";
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage25);
            this.tabControl6.Controls.Add(this.tabPage26);
            this.tabControl6.Controls.Add(this.tabPage27);
            this.tabControl6.Location = new System.Drawing.Point(3, 31);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(1282, 520);
            this.tabControl6.TabIndex = 0;
            // 
            // tabPage25
            // 
            this.tabPage25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.tabPage25.Controls.Add(this.dataGridView29);
            this.tabPage25.Controls.Add(this.dataGridView30);
            this.tabPage25.Controls.Add(this.label86);
            this.tabPage25.Controls.Add(this.label87);
            this.tabPage25.Controls.Add(this.dataGridView31);
            this.tabPage25.Controls.Add(this.dataGridView32);
            this.tabPage25.Controls.Add(this.label88);
            this.tabPage25.Controls.Add(this.label89);
            this.tabPage25.Controls.Add(this.dataGridView27);
            this.tabPage25.Controls.Add(this.dataGridView28);
            this.tabPage25.Controls.Add(this.label84);
            this.tabPage25.Controls.Add(this.label85);
            this.tabPage25.Controls.Add(this.dataGridView25);
            this.tabPage25.Controls.Add(this.dataGridView26);
            this.tabPage25.Controls.Add(this.label82);
            this.tabPage25.Controls.Add(this.label83);
            this.tabPage25.Controls.Add(this.dataGridView23);
            this.tabPage25.Controls.Add(this.dataGridView24);
            this.tabPage25.Controls.Add(this.label80);
            this.tabPage25.Controls.Add(this.label81);
            this.tabPage25.Controls.Add(this.dataGridView22);
            this.tabPage25.Controls.Add(this.dataGridView21);
            this.tabPage25.Controls.Add(this.label79);
            this.tabPage25.Controls.Add(this.label77);
            this.tabPage25.ForeColor = System.Drawing.Color.DarkOrange;
            this.tabPage25.Location = new System.Drawing.Point(4, 27);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(1274, 489);
            this.tabPage25.TabIndex = 0;
            this.tabPage25.Text = "InterestArea";
            // 
            // dataGridView29
            // 
            this.dataGridView29.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView29.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn21});
            this.dataGridView29.Location = new System.Drawing.Point(1058, 276);
            this.dataGridView29.Name = "dataGridView29";
            this.dataGridView29.Size = new System.Drawing.Size(158, 150);
            this.dataGridView29.TabIndex = 25;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn21.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.Width = 10000;
            // 
            // dataGridView30
            // 
            this.dataGridView30.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView30.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn22});
            this.dataGridView30.Location = new System.Drawing.Point(842, 276);
            this.dataGridView30.Name = "dataGridView30";
            this.dataGridView30.Size = new System.Drawing.Size(168, 150);
            this.dataGridView30.TabIndex = 24;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn22.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.Width = 10000;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(1011, 241);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(68, 18);
            this.label86.TabIndex = 23;
            this.label86.Text = "label86";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(810, 241);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(68, 18);
            this.label87.TabIndex = 22;
            this.label87.Text = "label87";
            // 
            // dataGridView31
            // 
            this.dataGridView31.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView31.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn23});
            this.dataGridView31.Location = new System.Drawing.Point(1058, 73);
            this.dataGridView31.Name = "dataGridView31";
            this.dataGridView31.Size = new System.Drawing.Size(158, 150);
            this.dataGridView31.TabIndex = 21;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn23.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.Width = 10000;
            // 
            // dataGridView32
            // 
            this.dataGridView32.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView32.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn24});
            this.dataGridView32.Location = new System.Drawing.Point(842, 73);
            this.dataGridView32.Name = "dataGridView32";
            this.dataGridView32.Size = new System.Drawing.Size(168, 150);
            this.dataGridView32.TabIndex = 20;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn24.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.Width = 10000;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(1042, 38);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(68, 18);
            this.label88.TabIndex = 19;
            this.label88.Text = "label88";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(820, 38);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(68, 18);
            this.label89.TabIndex = 18;
            this.label89.Text = "label89";
            // 
            // dataGridView27
            // 
            this.dataGridView27.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView27.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19});
            this.dataGridView27.Location = new System.Drawing.Point(644, 276);
            this.dataGridView27.Name = "dataGridView27";
            this.dataGridView27.Size = new System.Drawing.Size(155, 150);
            this.dataGridView27.TabIndex = 17;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn19.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.Width = 10000;
            // 
            // dataGridView28
            // 
            this.dataGridView28.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView28.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn20});
            this.dataGridView28.Location = new System.Drawing.Point(428, 276);
            this.dataGridView28.Name = "dataGridView28";
            this.dataGridView28.Size = new System.Drawing.Size(172, 150);
            this.dataGridView28.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn20.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.Width = 10000;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(592, 241);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(68, 18);
            this.label84.TabIndex = 15;
            this.label84.Text = "label84";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(425, 241);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(68, 18);
            this.label85.TabIndex = 14;
            this.label85.Text = "label85";
            // 
            // dataGridView25
            // 
            this.dataGridView25.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView25.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn17});
            this.dataGridView25.Location = new System.Drawing.Point(241, 276);
            this.dataGridView25.Name = "dataGridView25";
            this.dataGridView25.Size = new System.Drawing.Size(157, 150);
            this.dataGridView25.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn17.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.Width = 10000;
            // 
            // dataGridView26
            // 
            this.dataGridView26.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView26.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn18});
            this.dataGridView26.Location = new System.Drawing.Point(-4, 276);
            this.dataGridView26.Name = "dataGridView26";
            this.dataGridView26.Size = new System.Drawing.Size(201, 150);
            this.dataGridView26.TabIndex = 12;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn18.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.Width = 10000;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(238, 241);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(68, 18);
            this.label82.TabIndex = 11;
            this.label82.Text = "label82";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(55, 241);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(68, 18);
            this.label83.TabIndex = 10;
            this.label83.Text = "label83";
            // 
            // dataGridView23
            // 
            this.dataGridView23.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView23.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn15});
            this.dataGridView23.Location = new System.Drawing.Point(644, 73);
            this.dataGridView23.Name = "dataGridView23";
            this.dataGridView23.Size = new System.Drawing.Size(155, 150);
            this.dataGridView23.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn15.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.Width = 10000;
            // 
            // dataGridView24
            // 
            this.dataGridView24.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView24.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn16});
            this.dataGridView24.Location = new System.Drawing.Point(428, 73);
            this.dataGridView24.Name = "dataGridView24";
            this.dataGridView24.Size = new System.Drawing.Size(172, 150);
            this.dataGridView24.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn16.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Width = 10000;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(641, 38);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(68, 18);
            this.label80.TabIndex = 7;
            this.label80.Text = "label80";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(458, 38);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(68, 18);
            this.label81.TabIndex = 6;
            this.label81.Text = "label81";
            // 
            // dataGridView22
            // 
            this.dataGridView22.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView22.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn14});
            this.dataGridView22.Location = new System.Drawing.Point(241, 73);
            this.dataGridView22.Name = "dataGridView22";
            this.dataGridView22.Size = new System.Drawing.Size(157, 150);
            this.dataGridView22.TabIndex = 5;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn14.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Width = 10000;
            // 
            // dataGridView21
            // 
            this.dataGridView21.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView21.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column12});
            this.dataGridView21.Location = new System.Drawing.Point(0, 73);
            this.dataGridView21.Name = "dataGridView21";
            this.dataGridView21.Size = new System.Drawing.Size(197, 150);
            this.dataGridView21.TabIndex = 4;
            // 
            // Column12
            // 
            this.Column12.FillWeight = 10000F;
            this.Column12.HeaderText = "Citations";
            this.Column12.Name = "Column12";
            this.Column12.Width = 10000;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(238, 38);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(68, 18);
            this.label79.TabIndex = 3;
            this.label79.Text = "label79";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(55, 38);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(68, 18);
            this.label77.TabIndex = 2;
            this.label77.Text = "label77";
            // 
            // tabPage26
            // 
            this.tabPage26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.tabPage26.Controls.Add(this.label112);
            this.tabPage26.Controls.Add(this.dataGridView44);
            this.tabPage26.Controls.Add(this.label113);
            this.tabPage26.Controls.Add(this.label110);
            this.tabPage26.Controls.Add(this.dataGridView43);
            this.tabPage26.Controls.Add(this.label111);
            this.tabPage26.Controls.Add(this.label108);
            this.tabPage26.Controls.Add(this.dataGridView42);
            this.tabPage26.Controls.Add(this.label109);
            this.tabPage26.Controls.Add(this.label106);
            this.tabPage26.Controls.Add(this.dataGridView41);
            this.tabPage26.Controls.Add(this.label107);
            this.tabPage26.Controls.Add(this.label104);
            this.tabPage26.Controls.Add(this.dataGridView40);
            this.tabPage26.Controls.Add(this.label105);
            this.tabPage26.Controls.Add(this.label102);
            this.tabPage26.Controls.Add(this.dataGridView39);
            this.tabPage26.Controls.Add(this.label103);
            this.tabPage26.Controls.Add(this.label100);
            this.tabPage26.Controls.Add(this.dataGridView38);
            this.tabPage26.Controls.Add(this.label101);
            this.tabPage26.Controls.Add(this.label98);
            this.tabPage26.Controls.Add(this.dataGridView37);
            this.tabPage26.Controls.Add(this.label99);
            this.tabPage26.Controls.Add(this.label96);
            this.tabPage26.Controls.Add(this.dataGridView36);
            this.tabPage26.Controls.Add(this.label97);
            this.tabPage26.Controls.Add(this.label94);
            this.tabPage26.Controls.Add(this.dataGridView35);
            this.tabPage26.Controls.Add(this.label95);
            this.tabPage26.Controls.Add(this.label92);
            this.tabPage26.Controls.Add(this.dataGridView34);
            this.tabPage26.Controls.Add(this.label93);
            this.tabPage26.Controls.Add(this.label91);
            this.tabPage26.Controls.Add(this.dataGridView33);
            this.tabPage26.Controls.Add(this.label90);
            this.tabPage26.Location = new System.Drawing.Point(4, 27);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage26.Size = new System.Drawing.Size(1274, 489);
            this.tabPage26.TabIndex = 1;
            this.tabPage26.Text = "Faculty Research";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(1049, 298);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(78, 18);
            this.label112.TabIndex = 35;
            this.label112.Text = "label112";
            // 
            // dataGridView44
            // 
            this.dataGridView44.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView44.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn35});
            this.dataGridView44.Location = new System.Drawing.Point(1052, 339);
            this.dataGridView44.Name = "dataGridView44";
            this.dataGridView44.Size = new System.Drawing.Size(151, 150);
            this.dataGridView44.TabIndex = 34;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn35.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.Width = 10000;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(1049, 259);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(78, 18);
            this.label113.TabIndex = 33;
            this.label113.Text = "label113";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(861, 298);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(78, 18);
            this.label110.TabIndex = 32;
            this.label110.Text = "label110";
            // 
            // dataGridView43
            // 
            this.dataGridView43.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView43.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn34});
            this.dataGridView43.Location = new System.Drawing.Point(864, 339);
            this.dataGridView43.Name = "dataGridView43";
            this.dataGridView43.Size = new System.Drawing.Size(151, 150);
            this.dataGridView43.TabIndex = 31;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn34.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.Width = 10000;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(861, 259);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(78, 18);
            this.label111.TabIndex = 30;
            this.label111.Text = "label111";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(655, 292);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(78, 18);
            this.label108.TabIndex = 29;
            this.label108.Text = "label108";
            // 
            // dataGridView42
            // 
            this.dataGridView42.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView42.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn33});
            this.dataGridView42.Location = new System.Drawing.Point(658, 333);
            this.dataGridView42.Name = "dataGridView42";
            this.dataGridView42.Size = new System.Drawing.Size(151, 150);
            this.dataGridView42.TabIndex = 28;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn33.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.Width = 10000;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(655, 253);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(78, 18);
            this.label109.TabIndex = 27;
            this.label109.Text = "label109";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(450, 292);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(78, 18);
            this.label106.TabIndex = 26;
            this.label106.Text = "label106";
            // 
            // dataGridView41
            // 
            this.dataGridView41.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView41.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn32});
            this.dataGridView41.Location = new System.Drawing.Point(453, 333);
            this.dataGridView41.Name = "dataGridView41";
            this.dataGridView41.Size = new System.Drawing.Size(151, 150);
            this.dataGridView41.TabIndex = 25;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn32.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.Width = 10000;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(450, 253);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(78, 18);
            this.label107.TabIndex = 24;
            this.label107.Text = "label107";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(232, 292);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(78, 18);
            this.label104.TabIndex = 23;
            this.label104.Text = "label104";
            // 
            // dataGridView40
            // 
            this.dataGridView40.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView40.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn31});
            this.dataGridView40.Location = new System.Drawing.Point(235, 333);
            this.dataGridView40.Name = "dataGridView40";
            this.dataGridView40.Size = new System.Drawing.Size(151, 150);
            this.dataGridView40.TabIndex = 22;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn31.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.Width = 10000;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(232, 253);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(78, 18);
            this.label105.TabIndex = 21;
            this.label105.Text = "label105";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(7, 292);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(78, 18);
            this.label102.TabIndex = 20;
            this.label102.Text = "label102";
            // 
            // dataGridView39
            // 
            this.dataGridView39.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView39.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn30});
            this.dataGridView39.Location = new System.Drawing.Point(10, 333);
            this.dataGridView39.Name = "dataGridView39";
            this.dataGridView39.Size = new System.Drawing.Size(151, 150);
            this.dataGridView39.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn30.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.Width = 10000;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(7, 253);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(78, 18);
            this.label103.TabIndex = 18;
            this.label103.Text = "label103";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(1049, 58);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(78, 18);
            this.label100.TabIndex = 17;
            this.label100.Text = "label100";
            // 
            // dataGridView38
            // 
            this.dataGridView38.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView38.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn29});
            this.dataGridView38.Location = new System.Drawing.Point(1052, 99);
            this.dataGridView38.Name = "dataGridView38";
            this.dataGridView38.Size = new System.Drawing.Size(151, 150);
            this.dataGridView38.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn29.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.Width = 10000;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(1049, 19);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(78, 18);
            this.label101.TabIndex = 15;
            this.label101.Text = "label101";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(861, 58);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(68, 18);
            this.label98.TabIndex = 14;
            this.label98.Text = "label98";
            // 
            // dataGridView37
            // 
            this.dataGridView37.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView37.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn28});
            this.dataGridView37.Location = new System.Drawing.Point(864, 99);
            this.dataGridView37.Name = "dataGridView37";
            this.dataGridView37.Size = new System.Drawing.Size(151, 150);
            this.dataGridView37.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn28.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.Width = 10000;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(861, 19);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(68, 18);
            this.label99.TabIndex = 12;
            this.label99.Text = "label99";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(655, 58);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(68, 18);
            this.label96.TabIndex = 11;
            this.label96.Text = "label96";
            // 
            // dataGridView36
            // 
            this.dataGridView36.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView36.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn27});
            this.dataGridView36.Location = new System.Drawing.Point(658, 99);
            this.dataGridView36.Name = "dataGridView36";
            this.dataGridView36.Size = new System.Drawing.Size(151, 150);
            this.dataGridView36.TabIndex = 10;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn27.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.Width = 10000;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(655, 19);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(68, 18);
            this.label97.TabIndex = 9;
            this.label97.Text = "label97";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(450, 58);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(68, 18);
            this.label94.TabIndex = 8;
            this.label94.Text = "label94";
            // 
            // dataGridView35
            // 
            this.dataGridView35.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView35.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn26});
            this.dataGridView35.Location = new System.Drawing.Point(453, 99);
            this.dataGridView35.Name = "dataGridView35";
            this.dataGridView35.Size = new System.Drawing.Size(151, 150);
            this.dataGridView35.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn26.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.Width = 10000;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(450, 19);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(68, 18);
            this.label95.TabIndex = 6;
            this.label95.Text = "label95";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(232, 58);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(68, 18);
            this.label92.TabIndex = 5;
            this.label92.Text = "label92";
            // 
            // dataGridView34
            // 
            this.dataGridView34.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView34.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn25});
            this.dataGridView34.Location = new System.Drawing.Point(235, 99);
            this.dataGridView34.Name = "dataGridView34";
            this.dataGridView34.Size = new System.Drawing.Size(151, 150);
            this.dataGridView34.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn25.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.Width = 10000;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(232, 19);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(68, 18);
            this.label93.TabIndex = 3;
            this.label93.Text = "label93";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(7, 58);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(68, 18);
            this.label91.TabIndex = 2;
            this.label91.Text = "label91";
            // 
            // dataGridView33
            // 
            this.dataGridView33.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView33.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column13});
            this.dataGridView33.Location = new System.Drawing.Point(10, 99);
            this.dataGridView33.Name = "dataGridView33";
            this.dataGridView33.Size = new System.Drawing.Size(151, 150);
            this.dataGridView33.TabIndex = 1;
            // 
            // Column13
            // 
            this.Column13.FillWeight = 10000F;
            this.Column13.HeaderText = "Citations";
            this.Column13.Name = "Column13";
            this.Column13.Width = 10000;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(7, 19);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(68, 18);
            this.label90.TabIndex = 0;
            this.label90.Text = "label90";
            // 
            // tabPage27
            // 
            this.tabPage27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.tabPage27.Controls.Add(this.label114);
            this.tabPage27.Controls.Add(this.dataGridView45);
            this.tabPage27.Controls.Add(this.label115);
            this.tabPage27.Controls.Add(this.label116);
            this.tabPage27.Controls.Add(this.dataGridView46);
            this.tabPage27.Controls.Add(this.label117);
            this.tabPage27.Controls.Add(this.label118);
            this.tabPage27.Controls.Add(this.dataGridView47);
            this.tabPage27.Controls.Add(this.label119);
            this.tabPage27.Controls.Add(this.label120);
            this.tabPage27.Controls.Add(this.dataGridView48);
            this.tabPage27.Controls.Add(this.label121);
            this.tabPage27.Controls.Add(this.label122);
            this.tabPage27.Controls.Add(this.dataGridView49);
            this.tabPage27.Controls.Add(this.label123);
            this.tabPage27.Controls.Add(this.label124);
            this.tabPage27.Controls.Add(this.dataGridView50);
            this.tabPage27.Controls.Add(this.label125);
            this.tabPage27.Controls.Add(this.label126);
            this.tabPage27.Controls.Add(this.dataGridView51);
            this.tabPage27.Controls.Add(this.label127);
            this.tabPage27.Controls.Add(this.label128);
            this.tabPage27.Controls.Add(this.dataGridView52);
            this.tabPage27.Controls.Add(this.label129);
            this.tabPage27.Location = new System.Drawing.Point(4, 27);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Size = new System.Drawing.Size(1274, 489);
            this.tabPage27.TabIndex = 2;
            this.tabPage27.Text = "Faculty Research 2";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(884, 285);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(78, 18);
            this.label114.TabIndex = 53;
            this.label114.Text = "label114";
            // 
            // dataGridView45
            // 
            this.dataGridView45.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView45.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn36});
            this.dataGridView45.Location = new System.Drawing.Point(887, 326);
            this.dataGridView45.Name = "dataGridView45";
            this.dataGridView45.Size = new System.Drawing.Size(151, 150);
            this.dataGridView45.TabIndex = 52;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn36.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.Width = 10000;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(884, 246);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(78, 18);
            this.label115.TabIndex = 51;
            this.label115.Text = "label115";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(679, 285);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(78, 18);
            this.label116.TabIndex = 50;
            this.label116.Text = "label116";
            // 
            // dataGridView46
            // 
            this.dataGridView46.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView46.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn37});
            this.dataGridView46.Location = new System.Drawing.Point(682, 326);
            this.dataGridView46.Name = "dataGridView46";
            this.dataGridView46.Size = new System.Drawing.Size(151, 150);
            this.dataGridView46.TabIndex = 49;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn37.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.Width = 10000;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(679, 246);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(78, 18);
            this.label117.TabIndex = 48;
            this.label117.Text = "label117";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(461, 285);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(78, 18);
            this.label118.TabIndex = 47;
            this.label118.Text = "label118";
            // 
            // dataGridView47
            // 
            this.dataGridView47.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView47.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn38});
            this.dataGridView47.Location = new System.Drawing.Point(464, 326);
            this.dataGridView47.Name = "dataGridView47";
            this.dataGridView47.Size = new System.Drawing.Size(151, 150);
            this.dataGridView47.TabIndex = 46;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn38.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.Width = 10000;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(461, 246);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(78, 18);
            this.label119.TabIndex = 45;
            this.label119.Text = "label119";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(236, 285);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(78, 18);
            this.label120.TabIndex = 44;
            this.label120.Text = "label120";
            // 
            // dataGridView48
            // 
            this.dataGridView48.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView48.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn39});
            this.dataGridView48.Location = new System.Drawing.Point(239, 326);
            this.dataGridView48.Name = "dataGridView48";
            this.dataGridView48.Size = new System.Drawing.Size(151, 150);
            this.dataGridView48.TabIndex = 43;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn39.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.Width = 10000;
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(236, 246);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(78, 18);
            this.label121.TabIndex = 42;
            this.label121.Text = "label121";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(884, 51);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(78, 18);
            this.label122.TabIndex = 41;
            this.label122.Text = "label122";
            // 
            // dataGridView49
            // 
            this.dataGridView49.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView49.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn40});
            this.dataGridView49.Location = new System.Drawing.Point(887, 92);
            this.dataGridView49.Name = "dataGridView49";
            this.dataGridView49.Size = new System.Drawing.Size(151, 150);
            this.dataGridView49.TabIndex = 40;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn40.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.Width = 10000;
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(884, 12);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(78, 18);
            this.label123.TabIndex = 39;
            this.label123.Text = "label123";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(679, 51);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(78, 18);
            this.label124.TabIndex = 38;
            this.label124.Text = "label124";
            // 
            // dataGridView50
            // 
            this.dataGridView50.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView50.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn41});
            this.dataGridView50.Location = new System.Drawing.Point(682, 92);
            this.dataGridView50.Name = "dataGridView50";
            this.dataGridView50.Size = new System.Drawing.Size(151, 150);
            this.dataGridView50.TabIndex = 37;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn41.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.Width = 10000;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(679, 12);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(78, 18);
            this.label125.TabIndex = 36;
            this.label125.Text = "label125";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(461, 51);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(78, 18);
            this.label126.TabIndex = 35;
            this.label126.Text = "label126";
            // 
            // dataGridView51
            // 
            this.dataGridView51.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView51.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn42});
            this.dataGridView51.Location = new System.Drawing.Point(464, 92);
            this.dataGridView51.Name = "dataGridView51";
            this.dataGridView51.Size = new System.Drawing.Size(151, 150);
            this.dataGridView51.TabIndex = 34;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn42.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.Width = 10000;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(461, 12);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(78, 18);
            this.label127.TabIndex = 33;
            this.label127.Text = "label127";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(236, 51);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(78, 18);
            this.label128.TabIndex = 32;
            this.label128.Text = "label128";
            // 
            // dataGridView52
            // 
            this.dataGridView52.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView52.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn43});
            this.dataGridView52.Location = new System.Drawing.Point(239, 92);
            this.dataGridView52.Name = "dataGridView52";
            this.dataGridView52.Size = new System.Drawing.Size(151, 150);
            this.dataGridView52.TabIndex = 31;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn43.HeaderText = "Citations";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.Width = 10000;
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(236, 12);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(78, 18);
            this.label129.TabIndex = 30;
            this.label129.Text = "label129";
            // 
            // tabePage10
            // 
            this.tabePage10.BackColor = System.Drawing.Color.Black;
            this.tabePage10.Controls.Add(this.tabControl3);
            this.tabePage10.Location = new System.Drawing.Point(4, 22);
            this.tabePage10.Name = "tabePage10";
            this.tabePage10.Size = new System.Drawing.Size(1329, 936);
            this.tabePage10.TabIndex = 7;
            this.tabePage10.Text = "Course";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage13);
            this.tabControl3.Controls.Add(this.tabPage14);
            this.tabControl3.Controls.Add(this.tabPage15);
            this.tabControl3.Location = new System.Drawing.Point(3, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1258, 633);
            this.tabControl3.TabIndex = 2;
            // 
            // tabPage13
            // 
            this.tabPage13.BackgroundImage = global::IsteWebpage.Properties.Resources.grey_texture_minimalistic_hd_wallpaper_2560x1440_3868;
            this.tabPage13.Controls.Add(this.panel19);
            this.tabPage13.Controls.Add(this.panel18);
            this.tabPage13.Controls.Add(this.panel9);
            this.tabPage13.Location = new System.Drawing.Point(4, 27);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(1250, 602);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "Minors";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.panel19.Controls.Add(this.richTextBox24);
            this.panel19.Controls.Add(this.label37);
            this.panel19.Controls.Add(this.dataGridView7);
            this.panel19.Controls.Add(this.richTextBox15);
            this.panel19.Controls.Add(this.label38);
            this.panel19.Location = new System.Drawing.Point(862, 10);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(382, 586);
            this.panel19.TabIndex = 3;
            // 
            // richTextBox24
            // 
            this.richTextBox24.Location = new System.Drawing.Point(33, 499);
            this.richTextBox24.Name = "richTextBox24";
            this.richTextBox24.Size = new System.Drawing.Size(298, 68);
            this.richTextBox24.TabIndex = 4;
            this.richTextBox24.Text = "";
            this.richTextBox24.TextChanged += new System.EventHandler(this.richTextBox24_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.Color.Linen;
            this.label37.Location = new System.Drawing.Point(46, 63);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(68, 18);
            this.label37.TabIndex = 3;
            this.label37.Text = "label37";
            // 
            // dataGridView7
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView7.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2});
            this.dataGridView7.Location = new System.Drawing.Point(33, 198);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(298, 260);
            this.dataGridView7.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 2500F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Courses";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 2500;
            // 
            // richTextBox15
            // 
            this.richTextBox15.Location = new System.Drawing.Point(33, 124);
            this.richTextBox15.Name = "richTextBox15";
            this.richTextBox15.Size = new System.Drawing.Size(298, 68);
            this.richTextBox15.TabIndex = 1;
            this.richTextBox15.Text = "";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.ForeColor = System.Drawing.Color.Linen;
            this.label38.Location = new System.Drawing.Point(46, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(68, 18);
            this.label38.TabIndex = 0;
            this.label38.Text = "label38";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel18.Controls.Add(this.richTextBox23);
            this.panel18.Controls.Add(this.label35);
            this.panel18.Controls.Add(this.dataGridView6);
            this.panel18.Controls.Add(this.richTextBox14);
            this.panel18.Controls.Add(this.label36);
            this.panel18.Location = new System.Drawing.Point(434, 8);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(382, 586);
            this.panel18.TabIndex = 2;
            // 
            // richTextBox23
            // 
            this.richTextBox23.Location = new System.Drawing.Point(33, 501);
            this.richTextBox23.Name = "richTextBox23";
            this.richTextBox23.Size = new System.Drawing.Size(298, 68);
            this.richTextBox23.TabIndex = 4;
            this.richTextBox23.Text = "";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.Color.Linen;
            this.label35.Location = new System.Drawing.Point(46, 63);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(68, 18);
            this.label35.TabIndex = 3;
            this.label35.Text = "label35";
            // 
            // dataGridView6
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dataGridView6.Location = new System.Drawing.Point(33, 198);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(298, 262);
            this.dataGridView6.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 2500F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Courses";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 2500;
            // 
            // richTextBox14
            // 
            this.richTextBox14.Location = new System.Drawing.Point(33, 124);
            this.richTextBox14.Name = "richTextBox14";
            this.richTextBox14.Size = new System.Drawing.Size(298, 68);
            this.richTextBox14.TabIndex = 1;
            this.richTextBox14.Text = "";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.ForeColor = System.Drawing.Color.Linen;
            this.label36.Location = new System.Drawing.Point(46, 16);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(68, 18);
            this.label36.TabIndex = 0;
            this.label36.Text = "label36";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel9.Controls.Add(this.richTextBox22);
            this.panel9.Controls.Add(this.label34);
            this.panel9.Controls.Add(this.dataGridView3);
            this.panel9.Controls.Add(this.richTextBox1);
            this.panel9.Controls.Add(this.label8);
            this.panel9.Location = new System.Drawing.Point(17, 10);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(382, 596);
            this.panel9.TabIndex = 1;
            // 
            // richTextBox22
            // 
            this.richTextBox22.Location = new System.Drawing.Point(33, 499);
            this.richTextBox22.Name = "richTextBox22";
            this.richTextBox22.Size = new System.Drawing.Size(298, 68);
            this.richTextBox22.TabIndex = 4;
            this.richTextBox22.Text = "";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.Color.Linen;
            this.label34.Location = new System.Drawing.Point(46, 63);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(68, 18);
            this.label34.TabIndex = 3;
            this.label34.Text = "label34";
            // 
            // dataGridView3
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column});
            this.dataGridView3.Location = new System.Drawing.Point(33, 198);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(298, 260);
            this.dataGridView3.TabIndex = 2;
            // 
            // Column
            // 
            this.Column.FillWeight = 2500F;
            this.Column.HeaderText = "Courses";
            this.Column.Name = "Column";
            this.Column.Width = 2500;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(33, 124);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(298, 68);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Linen;
            this.label8.Location = new System.Drawing.Point(46, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 18);
            this.label8.TabIndex = 0;
            this.label8.Text = "label8";
            // 
            // tabPage14
            // 
            this.tabPage14.BackgroundImage = global::IsteWebpage.Properties.Resources.grey_texture_minimalistic_hd_wallpaper_2560x1440_3868;
            this.tabPage14.Controls.Add(this.panel22);
            this.tabPage14.Controls.Add(this.panel21);
            this.tabPage14.Controls.Add(this.panel20);
            this.tabPage14.Location = new System.Drawing.Point(4, 27);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(1250, 602);
            this.tabPage14.TabIndex = 1;
            this.tabPage14.Text = "Minors2";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.panel22.Controls.Add(this.richTextBox26);
            this.panel22.Controls.Add(this.label43);
            this.panel22.Controls.Add(this.dataGridView10);
            this.panel22.Controls.Add(this.richTextBox18);
            this.panel22.Controls.Add(this.label44);
            this.panel22.Location = new System.Drawing.Point(842, 13);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(382, 586);
            this.panel22.TabIndex = 4;
            // 
            // richTextBox26
            // 
            this.richTextBox26.Location = new System.Drawing.Point(33, 484);
            this.richTextBox26.Name = "richTextBox26";
            this.richTextBox26.Size = new System.Drawing.Size(298, 68);
            this.richTextBox26.TabIndex = 4;
            this.richTextBox26.Text = "";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.ForeColor = System.Drawing.Color.Linen;
            this.label43.Location = new System.Drawing.Point(46, 63);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(68, 18);
            this.label43.TabIndex = 3;
            this.label43.Text = "label43";
            // 
            // dataGridView10
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView10.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5});
            this.dataGridView10.Location = new System.Drawing.Point(33, 198);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.Size = new System.Drawing.Size(298, 228);
            this.dataGridView10.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Courses";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 10000;
            // 
            // richTextBox18
            // 
            this.richTextBox18.Location = new System.Drawing.Point(33, 124);
            this.richTextBox18.Name = "richTextBox18";
            this.richTextBox18.Size = new System.Drawing.Size(298, 68);
            this.richTextBox18.TabIndex = 1;
            this.richTextBox18.Text = "";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.ForeColor = System.Drawing.Color.Linen;
            this.label44.Location = new System.Drawing.Point(46, 16);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(68, 18);
            this.label44.TabIndex = 0;
            this.label44.Text = "label44";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(179)))), ((int)(((byte)(80)))));
            this.panel21.Controls.Add(this.label41);
            this.panel21.Controls.Add(this.dataGridView9);
            this.panel21.Controls.Add(this.richTextBox17);
            this.panel21.Controls.Add(this.label42);
            this.panel21.ForeColor = System.Drawing.Color.Linen;
            this.panel21.Location = new System.Drawing.Point(434, 8);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(382, 586);
            this.panel21.TabIndex = 3;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(46, 63);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(68, 18);
            this.label41.TabIndex = 3;
            this.label41.Text = "label41";
            // 
            // dataGridView9
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView9.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4});
            this.dataGridView9.Location = new System.Drawing.Point(33, 198);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.Size = new System.Drawing.Size(298, 233);
            this.dataGridView9.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Courses";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 10000;
            // 
            // richTextBox17
            // 
            this.richTextBox17.Location = new System.Drawing.Point(33, 124);
            this.richTextBox17.Name = "richTextBox17";
            this.richTextBox17.Size = new System.Drawing.Size(298, 68);
            this.richTextBox17.TabIndex = 1;
            this.richTextBox17.Text = "";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(46, 16);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(68, 18);
            this.label42.TabIndex = 0;
            this.label42.Text = "label42";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.MediumOrchid;
            this.panel20.Controls.Add(this.richTextBox25);
            this.panel20.Controls.Add(this.label39);
            this.panel20.Controls.Add(this.dataGridView8);
            this.panel20.Controls.Add(this.richTextBox16);
            this.panel20.Controls.Add(this.label40);
            this.panel20.Location = new System.Drawing.Point(24, 13);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(382, 586);
            this.panel20.TabIndex = 2;
            // 
            // richTextBox25
            // 
            this.richTextBox25.Location = new System.Drawing.Point(33, 475);
            this.richTextBox25.Name = "richTextBox25";
            this.richTextBox25.Size = new System.Drawing.Size(298, 68);
            this.richTextBox25.TabIndex = 4;
            this.richTextBox25.Text = "";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.Color.Linen;
            this.label39.Location = new System.Drawing.Point(46, 63);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(68, 18);
            this.label39.TabIndex = 3;
            this.label39.Text = "label39";
            // 
            // dataGridView8
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView8.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3});
            this.dataGridView8.Location = new System.Drawing.Point(33, 198);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(298, 228);
            this.dataGridView8.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Courses";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 10000;
            // 
            // richTextBox16
            // 
            this.richTextBox16.Location = new System.Drawing.Point(33, 124);
            this.richTextBox16.Name = "richTextBox16";
            this.richTextBox16.Size = new System.Drawing.Size(298, 68);
            this.richTextBox16.TabIndex = 1;
            this.richTextBox16.Text = "";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.ForeColor = System.Drawing.Color.Linen;
            this.label40.Location = new System.Drawing.Point(46, 16);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(68, 18);
            this.label40.TabIndex = 0;
            this.label40.Text = "label40";
            // 
            // tabPage15
            // 
            this.tabPage15.BackgroundImage = global::IsteWebpage.Properties.Resources.grey_texture_minimalistic_hd_wallpaper_2560x1440_3868;
            this.tabPage15.Controls.Add(this.panel24);
            this.tabPage15.Controls.Add(this.panel23);
            this.tabPage15.Location = new System.Drawing.Point(4, 27);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Size = new System.Drawing.Size(1250, 602);
            this.tabPage15.TabIndex = 2;
            this.tabPage15.Text = "Minors3";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel24.Controls.Add(this.richTextBox27);
            this.panel24.Controls.Add(this.label47);
            this.panel24.Controls.Add(this.dataGridView12);
            this.panel24.Controls.Add(this.richTextBox20);
            this.panel24.Controls.Add(this.label48);
            this.panel24.Location = new System.Drawing.Point(109, 16);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(382, 586);
            this.panel24.TabIndex = 4;
            // 
            // richTextBox27
            // 
            this.richTextBox27.Location = new System.Drawing.Point(33, 512);
            this.richTextBox27.Name = "richTextBox27";
            this.richTextBox27.Size = new System.Drawing.Size(298, 68);
            this.richTextBox27.TabIndex = 4;
            this.richTextBox27.Text = "";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.ForeColor = System.Drawing.Color.Linen;
            this.label47.Location = new System.Drawing.Point(46, 63);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(68, 18);
            this.label47.TabIndex = 3;
            this.label47.Text = "label47";
            // 
            // dataGridView12
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView12.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView12.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7});
            this.dataGridView12.Location = new System.Drawing.Point(33, 198);
            this.dataGridView12.Name = "dataGridView12";
            this.dataGridView12.Size = new System.Drawing.Size(298, 297);
            this.dataGridView12.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Courses";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 10000;
            // 
            // richTextBox20
            // 
            this.richTextBox20.Location = new System.Drawing.Point(33, 124);
            this.richTextBox20.Name = "richTextBox20";
            this.richTextBox20.Size = new System.Drawing.Size(298, 68);
            this.richTextBox20.TabIndex = 1;
            this.richTextBox20.Text = "";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.ForeColor = System.Drawing.Color.Linen;
            this.label48.Location = new System.Drawing.Point(46, 16);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(68, 18);
            this.label48.TabIndex = 0;
            this.label48.Text = "label48";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel23.Controls.Add(this.richTextBox28);
            this.panel23.Controls.Add(this.label45);
            this.panel23.Controls.Add(this.dataGridView11);
            this.panel23.Controls.Add(this.richTextBox19);
            this.panel23.Controls.Add(this.label46);
            this.panel23.Location = new System.Drawing.Point(714, 20);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(382, 586);
            this.panel23.TabIndex = 3;
            // 
            // richTextBox28
            // 
            this.richTextBox28.Location = new System.Drawing.Point(33, 508);
            this.richTextBox28.Name = "richTextBox28";
            this.richTextBox28.Size = new System.Drawing.Size(298, 68);
            this.richTextBox28.TabIndex = 4;
            this.richTextBox28.Text = "";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.ForeColor = System.Drawing.Color.Linen;
            this.label45.Location = new System.Drawing.Point(46, 63);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(68, 18);
            this.label45.TabIndex = 3;
            this.label45.Text = "label45";
            // 
            // dataGridView11
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView11.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6});
            this.dataGridView11.Location = new System.Drawing.Point(33, 198);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.Size = new System.Drawing.Size(298, 293);
            this.dataGridView11.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.FillWeight = 10000F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Courses";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 10000;
            // 
            // richTextBox19
            // 
            this.richTextBox19.Location = new System.Drawing.Point(33, 124);
            this.richTextBox19.Name = "richTextBox19";
            this.richTextBox19.Size = new System.Drawing.Size(298, 68);
            this.richTextBox19.TabIndex = 1;
            this.richTextBox19.Text = "";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.ForeColor = System.Drawing.Color.Linen;
            this.label46.Location = new System.Drawing.Point(46, 16);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(68, 18);
            this.label46.TabIndex = 0;
            this.label46.Text = "label46";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.webBrowser2);
            this.tabPage9.Controls.Add(this.pictureBox7);
            this.tabPage9.ImeMode = System.Windows.Forms.ImeMode.On;
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(1329, 936);
            this.tabPage9.TabIndex = 6;
            this.tabPage9.Text = "Contact";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // webBrowser2
            // 
            this.webBrowser2.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.webBrowser2.Location = new System.Drawing.Point(138, 60);
            this.webBrowser2.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser2.Name = "webBrowser2";
            this.webBrowser2.ScriptErrorsSuppressed = true;
            this.webBrowser2.Size = new System.Drawing.Size(1014, 498);
            this.webBrowser2.TabIndex = 0;
            this.webBrowser2.Url = new System.Uri("http://www.ist.rit.edu/api/contactForm/", System.UriKind.Absolute);
            this.webBrowser2.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser2_DocumentCompleted);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = global::IsteWebpage.Properties.Resources.current_forms;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox7.Location = new System.Drawing.Point(0, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(1329, 936);
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.Black;
            this.tabPage8.BackgroundImage = global::IsteWebpage.Properties.Resources.current_study_abroad;
            this.tabPage8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage8.Controls.Add(this.webBrowser1);
            this.tabPage8.Controls.Add(this.label6);
            this.tabPage8.Controls.Add(this.button1);
            this.tabPage8.Font = new System.Drawing.Font("Swis721 Blk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1329, 936);
            this.tabPage8.TabIndex = 5;
            this.tabPage8.Text = "Map";
            this.tabPage8.Click += new System.EventHandler(this.tabPage8_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(198, 93);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(922, 490);
            this.webBrowser1.TabIndex = 5;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Swis721 BT", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(539, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(242, 34);
            this.label6.TabIndex = 4;
            this.label6.Text = "Employment Map";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Swis721 BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(603, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Show Map";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Black;
            this.tabPage5.Controls.Add(this.tabControl7);
            this.tabPage5.Controls.Add(this.label131);
            this.tabPage5.Controls.Add(this.label130);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1329, 936);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Resources";
            // 
            // tabControl7
            // 
            this.tabControl7.Controls.Add(this.tabPage28);
            this.tabControl7.Controls.Add(this.tabPage29);
            this.tabControl7.Controls.Add(this.tabPage30);
            this.tabControl7.Controls.Add(this.tabPage31);
            this.tabControl7.Controls.Add(this.tabPage32);
            this.tabControl7.Controls.Add(this.tabPage33);
            this.tabControl7.Location = new System.Drawing.Point(3, 93);
            this.tabControl7.Name = "tabControl7";
            this.tabControl7.SelectedIndex = 0;
            this.tabControl7.Size = new System.Drawing.Size(1268, 570);
            this.tabControl7.TabIndex = 2;
            // 
            // tabPage28
            // 
            this.tabPage28.BackgroundImage = global::IsteWebpage.Properties.Resources.current_study_abroad;
            this.tabPage28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage28.Controls.Add(this.richTextBox34);
            this.tabPage28.Controls.Add(this.label133);
            this.tabPage28.Controls.Add(this.dataGridView53);
            this.tabPage28.Location = new System.Drawing.Point(4, 27);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage28.Size = new System.Drawing.Size(1260, 539);
            this.tabPage28.TabIndex = 0;
            this.tabPage28.Text = "Study Abroad";
            this.tabPage28.UseVisualStyleBackColor = true;
            // 
            // richTextBox34
            // 
            this.richTextBox34.Location = new System.Drawing.Point(284, 81);
            this.richTextBox34.Name = "richTextBox34";
            this.richTextBox34.Size = new System.Drawing.Size(537, 96);
            this.richTextBox34.TabIndex = 4;
            this.richTextBox34.Text = "";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.ForeColor = System.Drawing.Color.Linen;
            this.label133.Location = new System.Drawing.Point(508, 40);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(78, 18);
            this.label133.TabIndex = 3;
            this.label133.Text = "label133";
            // 
            // dataGridView53
            // 
            this.dataGridView53.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView53.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column14,
            this.Column15});
            this.dataGridView53.Location = new System.Drawing.Point(22, 183);
            this.dataGridView53.Name = "dataGridView53";
            this.dataGridView53.Size = new System.Drawing.Size(1232, 341);
            this.dataGridView53.TabIndex = 2;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Place";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.FillWeight = 10000F;
            this.Column15.HeaderText = "Description";
            this.Column15.Name = "Column15";
            this.Column15.Width = 10000;
            // 
            // tabPage29
            // 
            this.tabPage29.BackgroundImage = global::IsteWebpage.Properties.Resources.current_study_abroad;
            this.tabPage29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage29.Controls.Add(this.tabControl8);
            this.tabPage29.Controls.Add(this.label132);
            this.tabPage29.Location = new System.Drawing.Point(4, 27);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage29.Size = new System.Drawing.Size(1260, 539);
            this.tabPage29.TabIndex = 1;
            this.tabPage29.Text = "Student Services";
            this.tabPage29.UseVisualStyleBackColor = true;
            // 
            // tabControl8
            // 
            this.tabControl8.Controls.Add(this.tabPage34);
            this.tabControl8.Controls.Add(this.tabPage35);
            this.tabControl8.Controls.Add(this.tabPage36);
            this.tabControl8.Location = new System.Drawing.Point(3, 58);
            this.tabControl8.Name = "tabControl8";
            this.tabControl8.SelectedIndex = 0;
            this.tabControl8.Size = new System.Drawing.Size(1251, 475);
            this.tabControl8.TabIndex = 1;
            // 
            // tabPage34
            // 
            this.tabPage34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(179)))), ((int)(((byte)(80)))));
            this.tabPage34.Controls.Add(this.dataGridView54);
            this.tabPage34.Controls.Add(this.label134);
            this.tabPage34.ForeColor = System.Drawing.Color.Black;
            this.tabPage34.Location = new System.Drawing.Point(4, 27);
            this.tabPage34.Name = "tabPage34";
            this.tabPage34.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage34.Size = new System.Drawing.Size(1243, 444);
            this.tabPage34.TabIndex = 0;
            this.tabPage34.Text = "Professional Advisors";
            // 
            // dataGridView54
            // 
            this.dataGridView54.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView54.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column16,
            this.Column17,
            this.Column18});
            this.dataGridView54.Location = new System.Drawing.Point(-4, 94);
            this.dataGridView54.Name = "dataGridView54";
            this.dataGridView54.Size = new System.Drawing.Size(1192, 344);
            this.dataGridView54.TabIndex = 1;
            // 
            // Column16
            // 
            this.Column16.FillWeight = 300F;
            this.Column16.HeaderText = "Name";
            this.Column16.Name = "Column16";
            this.Column16.Width = 300;
            // 
            // Column17
            // 
            this.Column17.FillWeight = 300F;
            this.Column17.HeaderText = "Department";
            this.Column17.Name = "Column17";
            this.Column17.Width = 300;
            // 
            // Column18
            // 
            this.Column18.FillWeight = 300F;
            this.Column18.HeaderText = "Email";
            this.Column18.Name = "Column18";
            this.Column18.Width = 300;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.ForeColor = System.Drawing.Color.Linen;
            this.label134.Location = new System.Drawing.Point(501, 49);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(78, 18);
            this.label134.TabIndex = 0;
            this.label134.Text = "label134";
            // 
            // tabPage35
            // 
            this.tabPage35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.tabPage35.Controls.Add(this.richTextBox35);
            this.tabPage35.Controls.Add(this.label135);
            this.tabPage35.Location = new System.Drawing.Point(4, 27);
            this.tabPage35.Name = "tabPage35";
            this.tabPage35.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage35.Size = new System.Drawing.Size(1243, 444);
            this.tabPage35.TabIndex = 1;
            this.tabPage35.Text = "Faculty Advisiors";
            // 
            // richTextBox35
            // 
            this.richTextBox35.Location = new System.Drawing.Point(362, 148);
            this.richTextBox35.Name = "richTextBox35";
            this.richTextBox35.Size = new System.Drawing.Size(413, 174);
            this.richTextBox35.TabIndex = 1;
            this.richTextBox35.Text = "";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.ForeColor = System.Drawing.Color.Linen;
            this.label135.Location = new System.Drawing.Point(501, 88);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(78, 18);
            this.label135.TabIndex = 0;
            this.label135.Text = "label135";
            // 
            // tabPage36
            // 
            this.tabPage36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.tabPage36.Controls.Add(this.dataGridView55);
            this.tabPage36.Controls.Add(this.label136);
            this.tabPage36.Location = new System.Drawing.Point(4, 27);
            this.tabPage36.Name = "tabPage36";
            this.tabPage36.Size = new System.Drawing.Size(1243, 444);
            this.tabPage36.TabIndex = 2;
            this.tabPage36.Text = "Minor Advising";
            // 
            // dataGridView55
            // 
            this.dataGridView55.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView55.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column19,
            this.Column20,
            this.Column21});
            this.dataGridView55.Location = new System.Drawing.Point(103, 107);
            this.dataGridView55.Name = "dataGridView55";
            this.dataGridView55.Size = new System.Drawing.Size(944, 317);
            this.dataGridView55.TabIndex = 1;
            // 
            // Column19
            // 
            this.Column19.FillWeight = 300F;
            this.Column19.HeaderText = "title";
            this.Column19.Name = "Column19";
            this.Column19.Width = 300;
            // 
            // Column20
            // 
            this.Column20.FillWeight = 300F;
            this.Column20.HeaderText = "Advisor";
            this.Column20.Name = "Column20";
            this.Column20.Width = 300;
            // 
            // Column21
            // 
            this.Column21.FillWeight = 300F;
            this.Column21.HeaderText = "Email";
            this.Column21.Name = "Column21";
            this.Column21.Width = 300;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.ForeColor = System.Drawing.Color.Linen;
            this.label136.Location = new System.Drawing.Point(504, 63);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(78, 18);
            this.label136.TabIndex = 0;
            this.label136.Text = "label136";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.ForeColor = System.Drawing.Color.Linen;
            this.label132.Location = new System.Drawing.Point(508, 37);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(78, 18);
            this.label132.TabIndex = 0;
            this.label132.Text = "label132";
            // 
            // tabPage30
            // 
            this.tabPage30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(152)))), ((int)(((byte)(117)))));
            this.tabPage30.Controls.Add(this.richTextBox36);
            this.tabPage30.Controls.Add(this.label138);
            this.tabPage30.Controls.Add(this.label137);
            this.tabPage30.Location = new System.Drawing.Point(4, 27);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Size = new System.Drawing.Size(1260, 539);
            this.tabPage30.TabIndex = 2;
            this.tabPage30.Text = "Tutor and Lab Information";
            // 
            // richTextBox36
            // 
            this.richTextBox36.Location = new System.Drawing.Point(380, 165);
            this.richTextBox36.Name = "richTextBox36";
            this.richTextBox36.Size = new System.Drawing.Size(372, 209);
            this.richTextBox36.TabIndex = 2;
            this.richTextBox36.Text = "";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.ForeColor = System.Drawing.Color.Linen;
            this.label138.Location = new System.Drawing.Point(508, 428);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(78, 18);
            this.label138.TabIndex = 1;
            this.label138.Text = "label138";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.ForeColor = System.Drawing.Color.Linen;
            this.label137.Location = new System.Drawing.Point(508, 113);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(78, 18);
            this.label137.TabIndex = 0;
            this.label137.Text = "label137";
            // 
            // tabPage31
            // 
            this.tabPage31.BackColor = System.Drawing.Color.MediumOrchid;
            this.tabPage31.Controls.Add(this.pictureBox5);
            this.tabPage31.Controls.Add(this.label141);
            this.tabPage31.Controls.Add(this.dataGridView56);
            this.tabPage31.Controls.Add(this.label140);
            this.tabPage31.Controls.Add(this.label139);
            this.tabPage31.Location = new System.Drawing.Point(4, 27);
            this.tabPage31.Name = "tabPage31";
            this.tabPage31.Size = new System.Drawing.Size(1260, 539);
            this.tabPage31.TabIndex = 3;
            this.tabPage31.Text = "Student Ambassadors";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(660, 102);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(480, 412);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.ForeColor = System.Drawing.Color.Linen;
            this.label141.Location = new System.Drawing.Point(175, 341);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(78, 18);
            this.label141.TabIndex = 4;
            this.label141.Text = "label141";
            // 
            // dataGridView56
            // 
            this.dataGridView56.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView56.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column22,
            this.Column23});
            this.dataGridView56.Location = new System.Drawing.Point(30, 145);
            this.dataGridView56.Name = "dataGridView56";
            this.dataGridView56.Size = new System.Drawing.Size(544, 150);
            this.dataGridView56.TabIndex = 2;
            // 
            // Column22
            // 
            this.Column22.FillWeight = 200F;
            this.Column22.HeaderText = "title";
            this.Column22.Name = "Column22";
            this.Column22.Width = 200;
            // 
            // Column23
            // 
            this.Column23.FillWeight = 6000F;
            this.Column23.HeaderText = "description";
            this.Column23.Name = "Column23";
            this.Column23.Width = 6000;
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.ForeColor = System.Drawing.Color.Linen;
            this.label140.Location = new System.Drawing.Point(175, 102);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(78, 18);
            this.label140.TabIndex = 1;
            this.label140.Text = "label140";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.ForeColor = System.Drawing.Color.Linen;
            this.label139.Location = new System.Drawing.Point(175, 35);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(78, 18);
            this.label139.TabIndex = 0;
            this.label139.Text = "label139";
            // 
            // tabPage32
            // 
            this.tabPage32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.tabPage32.Controls.Add(this.label145);
            this.tabPage32.Controls.Add(this.label144);
            this.tabPage32.Controls.Add(this.label143);
            this.tabPage32.Controls.Add(this.label142);
            this.tabPage32.Controls.Add(this.dataGridView57);
            this.tabPage32.Location = new System.Drawing.Point(4, 27);
            this.tabPage32.Name = "tabPage32";
            this.tabPage32.Size = new System.Drawing.Size(1260, 539);
            this.tabPage32.TabIndex = 4;
            this.tabPage32.Text = "Forms";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.ForeColor = System.Drawing.Color.Linen;
            this.label145.Location = new System.Drawing.Point(878, 82);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(151, 18);
            this.label145.TabIndex = 4;
            this.label145.Text = "UnderGrad Forms";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.ForeColor = System.Drawing.Color.Linen;
            this.label144.Location = new System.Drawing.Point(374, 78);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(138, 18);
            this.label144.TabIndex = 3;
            this.label144.Text = "Graduate Forms";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.ForeColor = System.Drawing.Color.Linen;
            this.label143.Location = new System.Drawing.Point(875, 268);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(78, 18);
            this.label143.TabIndex = 2;
            this.label143.Text = "label143";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.ForeColor = System.Drawing.Color.Linen;
            this.label142.Location = new System.Drawing.Point(872, 204);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(78, 18);
            this.label142.TabIndex = 1;
            this.label142.Text = "label142";
            // 
            // dataGridView57
            // 
            this.dataGridView57.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView57.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column24,
            this.Column25});
            this.dataGridView57.Location = new System.Drawing.Point(40, 181);
            this.dataGridView57.Name = "dataGridView57";
            this.dataGridView57.Size = new System.Drawing.Size(794, 212);
            this.dataGridView57.TabIndex = 0;
            // 
            // Column24
            // 
            this.Column24.FillWeight = 2000F;
            this.Column24.HeaderText = "Form Name";
            this.Column24.Name = "Column24";
            this.Column24.Width = 2000;
            // 
            // Column25
            // 
            this.Column25.FillWeight = 500F;
            this.Column25.HeaderText = "Href";
            this.Column25.Name = "Column25";
            this.Column25.Width = 500;
            // 
            // tabPage33
            // 
            this.tabPage33.BackColor = System.Drawing.Color.DimGray;
            this.tabPage33.BackgroundImage = global::IsteWebpage.Properties.Resources.grey_texture_minimalistic_hd_wallpaper_2560x1440_3868;
            this.tabPage33.Controls.Add(this.panel31);
            this.tabPage33.Controls.Add(this.panel30);
            this.tabPage33.Controls.Add(this.panel29);
            this.tabPage33.Controls.Add(this.label151);
            this.tabPage33.Controls.Add(this.label150);
            this.tabPage33.Controls.Add(this.panel28);
            this.tabPage33.Location = new System.Drawing.Point(4, 27);
            this.tabPage33.Name = "tabPage33";
            this.tabPage33.Size = new System.Drawing.Size(1260, 539);
            this.tabPage33.TabIndex = 5;
            this.tabPage33.Text = "Co-op Enrollment";
            this.tabPage33.Click += new System.EventHandler(this.tabPage33_Click);
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(179)))), ((int)(((byte)(80)))));
            this.panel31.Controls.Add(this.richTextBox40);
            this.panel31.Controls.Add(this.label149);
            this.panel31.Location = new System.Drawing.Point(961, 69);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(275, 402);
            this.panel31.TabIndex = 10;
            // 
            // richTextBox40
            // 
            this.richTextBox40.Location = new System.Drawing.Point(24, 112);
            this.richTextBox40.Name = "richTextBox40";
            this.richTextBox40.Size = new System.Drawing.Size(211, 260);
            this.richTextBox40.TabIndex = 1;
            this.richTextBox40.Text = "";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.ForeColor = System.Drawing.Color.Linen;
            this.label149.Location = new System.Drawing.Point(46, 43);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(78, 18);
            this.label149.TabIndex = 0;
            this.label149.Text = "label149";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.panel30.Controls.Add(this.richTextBox39);
            this.panel30.Controls.Add(this.label148);
            this.panel30.Location = new System.Drawing.Point(643, 69);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(275, 402);
            this.panel30.TabIndex = 9;
            // 
            // richTextBox39
            // 
            this.richTextBox39.Location = new System.Drawing.Point(24, 112);
            this.richTextBox39.Name = "richTextBox39";
            this.richTextBox39.Size = new System.Drawing.Size(211, 260);
            this.richTextBox39.TabIndex = 1;
            this.richTextBox39.Text = "";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.ForeColor = System.Drawing.Color.Linen;
            this.label148.Location = new System.Drawing.Point(46, 43);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(78, 18);
            this.label148.TabIndex = 0;
            this.label148.Text = "label148";
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel29.Controls.Add(this.richTextBox38);
            this.panel29.Controls.Add(this.label147);
            this.panel29.Location = new System.Drawing.Point(328, 69);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(275, 402);
            this.panel29.TabIndex = 8;
            // 
            // richTextBox38
            // 
            this.richTextBox38.Location = new System.Drawing.Point(24, 112);
            this.richTextBox38.Name = "richTextBox38";
            this.richTextBox38.Size = new System.Drawing.Size(212, 260);
            this.richTextBox38.TabIndex = 1;
            this.richTextBox38.Text = "";
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.ForeColor = System.Drawing.Color.Linen;
            this.label147.Location = new System.Drawing.Point(46, 43);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(78, 18);
            this.label147.TabIndex = 0;
            this.label147.Text = "label147";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label151.ForeColor = System.Drawing.Color.Linen;
            this.label151.Location = new System.Drawing.Point(508, 21);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(110, 25);
            this.label151.TabIndex = 7;
            this.label151.Text = "label151";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.ForeColor = System.Drawing.Color.Linen;
            this.label150.Location = new System.Drawing.Point(510, 497);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(78, 18);
            this.label150.TabIndex = 6;
            this.label150.Text = "label150";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel28.Controls.Add(this.richTextBox37);
            this.panel28.Controls.Add(this.label146);
            this.panel28.Location = new System.Drawing.Point(19, 69);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(271, 402);
            this.panel28.TabIndex = 2;
            // 
            // richTextBox37
            // 
            this.richTextBox37.Location = new System.Drawing.Point(24, 112);
            this.richTextBox37.Name = "richTextBox37";
            this.richTextBox37.Size = new System.Drawing.Size(210, 260);
            this.richTextBox37.TabIndex = 1;
            this.richTextBox37.Text = "";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.ForeColor = System.Drawing.Color.Linen;
            this.label146.Location = new System.Drawing.Point(46, 43);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(78, 18);
            this.label146.TabIndex = 0;
            this.label146.Text = "label146";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.Location = new System.Drawing.Point(515, 56);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(110, 25);
            this.label131.TabIndex = 1;
            this.label131.Text = "label131";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(515, 9);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(110, 25);
            this.label130.TabIndex = 0;
            this.label130.Text = "label130";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Black;
            this.tabPage4.Controls.Add(this.tabControl4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1329, 936);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "People";
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage17);
            this.tabControl4.Controls.Add(this.tabPage18);
            this.tabControl4.Location = new System.Drawing.Point(3, 0);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(1282, 694);
            this.tabControl4.TabIndex = 2;
            // 
            // tabPage17
            // 
            this.tabPage17.BackgroundImage = global::IsteWebpage.Properties.Resources.cover51;
            this.tabPage17.Controls.Add(this.panel26);
            this.tabPage17.Location = new System.Drawing.Point(4, 27);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(1274, 663);
            this.tabPage17.TabIndex = 0;
            this.tabPage17.Text = "Faculty";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel26.Controls.Add(this.richTextBox29);
            this.panel26.Controls.Add(this.label60);
            this.panel26.Controls.Add(this.label53);
            this.panel26.Controls.Add(this.label52);
            this.panel26.Controls.Add(this.pictureBox12);
            this.panel26.Controls.Add(this.label51);
            this.panel26.Controls.Add(this.label54);
            this.panel26.Controls.Add(this.label59);
            this.panel26.Controls.Add(this.button3);
            this.panel26.Controls.Add(this.label55);
            this.panel26.Controls.Add(this.button2);
            this.panel26.Controls.Add(this.label58);
            this.panel26.Controls.Add(this.label56);
            this.panel26.Controls.Add(this.label57);
            this.panel26.Location = new System.Drawing.Point(69, 27);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(1124, 588);
            this.panel26.TabIndex = 17;
            // 
            // richTextBox29
            // 
            this.richTextBox29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.richTextBox29.ForeColor = System.Drawing.Color.Linen;
            this.richTextBox29.Location = new System.Drawing.Point(495, 422);
            this.richTextBox29.Name = "richTextBox29";
            this.richTextBox29.Size = new System.Drawing.Size(293, 96);
            this.richTextBox29.TabIndex = 5;
            this.richTextBox29.Text = "area of interest";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.ForeColor = System.Drawing.Color.Linen;
            this.label60.Location = new System.Drawing.Point(492, 11);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(89, 18);
            this.label60.TabIndex = 16;
            this.label60.Text = "username";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.ForeColor = System.Drawing.Color.Linen;
            this.label53.Location = new System.Drawing.Point(492, 167);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(55, 18);
            this.label53.TabIndex = 8;
            this.label53.Text = "office";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.Color.Linen;
            this.label52.Location = new System.Drawing.Point(163, 67);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(40, 18);
            this.label52.TabIndex = 4;
            this.label52.Text = "title";
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox12.Cursor = System.Windows.Forms.Cursors.Help;
            this.pictureBox12.Location = new System.Drawing.Point(103, 115);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(236, 340);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox12.TabIndex = 15;
            this.pictureBox12.TabStop = false;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.ForeColor = System.Drawing.Color.Linen;
            this.label51.Location = new System.Drawing.Point(163, 11);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(55, 18);
            this.label51.TabIndex = 3;
            this.label51.Text = "Name";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.ForeColor = System.Drawing.Color.Linen;
            this.label54.Location = new System.Drawing.Point(492, 204);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(72, 18);
            this.label54.TabIndex = 9;
            this.label54.Text = "website";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.ForeColor = System.Drawing.Color.Linen;
            this.label59.Location = new System.Drawing.Point(492, 336);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(84, 18);
            this.label59.TabIndex = 14;
            this.label59.Text = "facebook";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button3.ForeColor = System.Drawing.Color.Linen;
            this.button3.Location = new System.Drawing.Point(249, 470);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 71);
            this.button3.TabIndex = 1;
            this.button3.Text = "Show Next";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.ForeColor = System.Drawing.Color.Linen;
            this.label55.Location = new System.Drawing.Point(492, 245);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(58, 18);
            this.label55.TabIndex = 10;
            this.label55.Text = "phone";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.button2.ForeColor = System.Drawing.Color.Linen;
            this.button2.Location = new System.Drawing.Point(25, 470);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 71);
            this.button2.TabIndex = 0;
            this.button2.Text = "Show Previous";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.ForeColor = System.Drawing.Color.Linen;
            this.label58.Location = new System.Drawing.Point(486, 115);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(64, 18);
            this.label58.TabIndex = 13;
            this.label58.Text = "tagline";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.ForeColor = System.Drawing.Color.Linen;
            this.label56.Location = new System.Drawing.Point(492, 293);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(53, 18);
            this.label56.TabIndex = 11;
            this.label56.Text = "email";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.ForeColor = System.Drawing.Color.Linen;
            this.label57.Location = new System.Drawing.Point(492, 386);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(62, 18);
            this.label57.TabIndex = 12;
            this.label57.Text = "twitter";
            // 
            // tabPage18
            // 
            this.tabPage18.BackgroundImage = global::IsteWebpage.Properties.Resources.cover51;
            this.tabPage18.Controls.Add(this.panel27);
            this.tabPage18.Location = new System.Drawing.Point(4, 27);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(1274, 663);
            this.tabPage18.TabIndex = 1;
            this.tabPage18.Text = "Staff";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel27.Controls.Add(this.richTextBox30);
            this.panel27.Controls.Add(this.label61);
            this.panel27.Controls.Add(this.label62);
            this.panel27.Controls.Add(this.label63);
            this.panel27.Controls.Add(this.pictureBox4);
            this.panel27.Controls.Add(this.label64);
            this.panel27.Controls.Add(this.label65);
            this.panel27.Controls.Add(this.label66);
            this.panel27.Controls.Add(this.button4);
            this.panel27.Controls.Add(this.label67);
            this.panel27.Controls.Add(this.button5);
            this.panel27.Controls.Add(this.label68);
            this.panel27.Controls.Add(this.label69);
            this.panel27.Controls.Add(this.label70);
            this.panel27.Location = new System.Drawing.Point(75, 37);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(1124, 588);
            this.panel27.TabIndex = 18;
            // 
            // richTextBox30
            // 
            this.richTextBox30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.richTextBox30.ForeColor = System.Drawing.Color.Linen;
            this.richTextBox30.Location = new System.Drawing.Point(495, 422);
            this.richTextBox30.Name = "richTextBox30";
            this.richTextBox30.Size = new System.Drawing.Size(293, 96);
            this.richTextBox30.TabIndex = 5;
            this.richTextBox30.Text = "area of interest";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.ForeColor = System.Drawing.Color.Linen;
            this.label61.Location = new System.Drawing.Point(492, 11);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(89, 18);
            this.label61.TabIndex = 16;
            this.label61.Text = "username";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.ForeColor = System.Drawing.Color.Linen;
            this.label62.Location = new System.Drawing.Point(492, 167);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(55, 18);
            this.label62.TabIndex = 8;
            this.label62.Text = "office";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.ForeColor = System.Drawing.Color.Linen;
            this.label63.Location = new System.Drawing.Point(163, 67);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(40, 18);
            this.label63.TabIndex = 4;
            this.label63.Text = "title";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Help;
            this.pictureBox4.Location = new System.Drawing.Point(103, 115);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(236, 340);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.ForeColor = System.Drawing.Color.Linen;
            this.label64.Location = new System.Drawing.Point(163, 11);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(55, 18);
            this.label64.TabIndex = 3;
            this.label64.Text = "Name";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.ForeColor = System.Drawing.Color.Linen;
            this.label65.Location = new System.Drawing.Point(492, 204);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(72, 18);
            this.label65.TabIndex = 9;
            this.label65.Text = "website";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.ForeColor = System.Drawing.Color.Linen;
            this.label66.Location = new System.Drawing.Point(492, 336);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(84, 18);
            this.label66.TabIndex = 14;
            this.label66.Text = "facebook";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button4.ForeColor = System.Drawing.Color.Linen;
            this.button4.Location = new System.Drawing.Point(249, 470);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(151, 71);
            this.button4.TabIndex = 1;
            this.button4.Text = "Show Next";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.ForeColor = System.Drawing.Color.Linen;
            this.label67.Location = new System.Drawing.Point(492, 245);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(58, 18);
            this.label67.TabIndex = 10;
            this.label67.Text = "phone";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.button5.ForeColor = System.Drawing.Color.Linen;
            this.button5.Location = new System.Drawing.Point(25, 470);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(153, 71);
            this.button5.TabIndex = 0;
            this.button5.Text = "Show Previous";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.ForeColor = System.Drawing.Color.Linen;
            this.label68.Location = new System.Drawing.Point(486, 115);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(64, 18);
            this.label68.TabIndex = 13;
            this.label68.Text = "tagline";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.ForeColor = System.Drawing.Color.Linen;
            this.label69.Location = new System.Drawing.Point(492, 293);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(53, 18);
            this.label69.TabIndex = 11;
            this.label69.Text = "email";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.ForeColor = System.Drawing.Color.Linen;
            this.label70.Location = new System.Drawing.Point(492, 386);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(62, 18);
            this.label70.TabIndex = 12;
            this.label70.Text = "twitter";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Black;
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.pictureBox8);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1329, 936);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Job Tables";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Swis721 Blk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Orange;
            this.label5.Location = new System.Drawing.Point(207, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 22);
            this.label5.TabIndex = 3;
            // 
            // dataGridView2
            // 
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Swis721 Blk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.LightSkyBlue;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Swis721 Blk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.DarkOrange;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridView2.Location = new System.Drawing.Point(51, 109);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView2.Size = new System.Drawing.Size(651, 473);
            this.dataGridView2.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Employer";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.FillWeight = 150F;
            this.Column2.HeaderText = "Degree";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.FillWeight = 300F;
            this.Column3.HeaderText = "City";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 300;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Title";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Start Date";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Swis721 Blk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Employer,
            this.Degree,
            this.City,
            this.Term});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.MenuText;
            this.dataGridView1.Location = new System.Drawing.Point(793, 109);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.Navy;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView1.Size = new System.Drawing.Size(518, 473);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // Employer
            // 
            this.Employer.HeaderText = "Employer";
            this.Employer.Name = "Employer";
            this.Employer.ReadOnly = true;
            // 
            // Degree
            // 
            this.Degree.HeaderText = "Degree";
            this.Degree.Name = "Degree";
            this.Degree.ReadOnly = true;
            // 
            // City
            // 
            this.City.FillWeight = 200F;
            this.City.HeaderText = "City";
            this.City.Name = "City";
            this.City.ReadOnly = true;
            this.City.Width = 200;
            // 
            // Term
            // 
            this.Term.HeaderText = "Term";
            this.Term.Name = "Term";
            this.Term.ReadOnly = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Swis721 Blk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(888, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 22);
            this.label7.TabIndex = 1;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = global::IsteWebpage.Properties.Resources.prospective_tutors_lab;
            this.pictureBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox8.Image = global::IsteWebpage.Properties.Resources.prospective_tutors_lab;
            this.pictureBox8.Location = new System.Drawing.Point(0, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(1329, 936);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.Transparent;
            this.tabPage10.BackgroundImage = global::IsteWebpage.Properties.Resources.prospective_tutors_lab;
            this.tabPage10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage10.Controls.Add(this.panel4);
            this.tabPage10.Controls.Add(this.label12);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(1329, 936);
            this.tabPage10.TabIndex = 8;
            this.tabPage10.Text = "Employment";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.richTextBox6);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.richTextBox5);
            this.panel4.ForeColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(94, 89);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1084, 506);
            this.panel4.TabIndex = 6;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.label14.Location = new System.Drawing.Point(151, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 18);
            this.label14.TabIndex = 4;
            this.label14.Text = "label14";
            // 
            // richTextBox6
            // 
            this.richTextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.richTextBox6.ForeColor = System.Drawing.Color.Linen;
            this.richTextBox6.Location = new System.Drawing.Point(35, 66);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(362, 412);
            this.richTextBox6.TabIndex = 5;
            this.richTextBox6.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.label13.Location = new System.Drawing.Point(822, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 18);
            this.label13.TabIndex = 3;
            this.label13.Text = "label13";
            // 
            // richTextBox5
            // 
            this.richTextBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.richTextBox5.ForeColor = System.Drawing.Color.Linen;
            this.richTextBox5.Location = new System.Drawing.Point(689, 66);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(362, 412);
            this.richTextBox5.TabIndex = 1;
            this.richTextBox5.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label12.Font = new System.Drawing.Font("Swis721 Blk BT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Linen;
            this.label12.Location = new System.Drawing.Point(359, 39);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 29);
            this.label12.TabIndex = 0;
            this.label12.Text = "label12";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1329, 936);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Degrees";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage11);
            this.tabControl2.Controls.Add(this.tabPage12);
            this.tabControl2.Location = new System.Drawing.Point(17, 20);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1265, 674);
            this.tabControl2.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.BackgroundImage = global::IsteWebpage.Properties.Resources.grey_texture_minimalistic_hd_wallpaper_2560x1440_3868;
            this.tabPage6.Controls.Add(this.panel8);
            this.tabPage6.Controls.Add(this.panel7);
            this.tabPage6.Controls.Add(this.panel6);
            this.tabPage6.Location = new System.Drawing.Point(4, 27);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1257, 643);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Undergraduate";
            this.tabPage6.UseVisualStyleBackColor = true;
            this.tabPage6.Click += new System.EventHandler(this.tabPage6_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.panel8.Controls.Add(this.dataGridView16);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.richTextBox4);
            this.panel8.Controls.Add(this.label11);
            this.panel8.Location = new System.Drawing.Point(872, 16);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(354, 575);
            this.panel8.TabIndex = 2;
            // 
            // dataGridView16
            // 
            this.dataGridView16.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView16.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10});
            this.dataGridView16.Location = new System.Drawing.Point(64, 365);
            this.dataGridView16.Name = "dataGridView16";
            this.dataGridView16.Size = new System.Drawing.Size(243, 176);
            this.dataGridView16.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.FillWeight = 2000F;
            this.dataGridViewTextBoxColumn10.HeaderText = "Concentrations";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 2000;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Linen;
            this.label25.Location = new System.Drawing.Point(122, 126);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(96, 25);
            this.label25.TabIndex = 3;
            this.label25.Text = "label25";
            // 
            // richTextBox4
            // 
            this.richTextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.richTextBox4.Location = new System.Drawing.Point(44, 197);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(280, 137);
            this.richTextBox4.TabIndex = 2;
            this.richTextBox4.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Linen;
            this.label11.Location = new System.Drawing.Point(39, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "label11";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel7.Controls.Add(this.dataGridView15);
            this.panel7.Controls.Add(this.label24);
            this.panel7.Controls.Add(this.richTextBox3);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Location = new System.Drawing.Point(460, 16);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(383, 575);
            this.panel7.TabIndex = 1;
            // 
            // dataGridView15
            // 
            this.dataGridView15.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView15.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9});
            this.dataGridView15.Location = new System.Drawing.Point(60, 365);
            this.dataGridView15.Name = "dataGridView15";
            this.dataGridView15.Size = new System.Drawing.Size(243, 176);
            this.dataGridView15.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.FillWeight = 2000F;
            this.dataGridViewTextBoxColumn9.HeaderText = "Concentrations";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 2000;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Linen;
            this.label24.Location = new System.Drawing.Point(79, 126);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(96, 25);
            this.label24.TabIndex = 2;
            this.label24.Text = "label24";
            // 
            // richTextBox3
            // 
            this.richTextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.richTextBox3.Location = new System.Drawing.Point(38, 197);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(314, 137);
            this.richTextBox3.TabIndex = 1;
            this.richTextBox3.Text = "";
            this.richTextBox3.TextChanged += new System.EventHandler(this.richTextBox3_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Linen;
            this.label10.Location = new System.Drawing.Point(33, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 16);
            this.label10.TabIndex = 0;
            this.label10.Text = "label10";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel6.Controls.Add(this.dataGridView14);
            this.panel6.Controls.Add(this.label23);
            this.panel6.Controls.Add(this.richTextBox2);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Location = new System.Drawing.Point(15, 16);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(409, 575);
            this.panel6.TabIndex = 0;
            // 
            // dataGridView14
            // 
            this.dataGridView14.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView14.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column8});
            this.dataGridView14.Location = new System.Drawing.Point(49, 365);
            this.dataGridView14.Name = "dataGridView14";
            this.dataGridView14.Size = new System.Drawing.Size(243, 176);
            this.dataGridView14.TabIndex = 3;
            // 
            // Column8
            // 
            this.Column8.FillWeight = 2000F;
            this.Column8.HeaderText = "Concentrations";
            this.Column8.Name = "Column8";
            this.Column8.Width = 2000;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Linen;
            this.label23.Location = new System.Drawing.Point(109, 126);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(96, 25);
            this.label23.TabIndex = 2;
            this.label23.Text = "label23";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.richTextBox2.Location = new System.Drawing.Point(19, 197);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(361, 137);
            this.richTextBox2.TabIndex = 1;
            this.richTextBox2.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Linen;
            this.label9.Location = new System.Drawing.Point(46, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "label9";
            // 
            // tabPage7
            // 
            this.tabPage7.BackgroundImage = global::IsteWebpage.Properties.Resources.grey_texture_minimalistic_hd_wallpaper_2560x1440_3868;
            this.tabPage7.Controls.Add(this.dataGridView17);
            this.tabPage7.Controls.Add(this.panel5);
            this.tabPage7.Controls.Add(this.label31);
            this.tabPage7.Controls.Add(this.label30);
            this.tabPage7.Controls.Add(this.panel10);
            this.tabPage7.Controls.Add(this.panel11);
            this.tabPage7.Controls.Add(this.label29);
            this.tabPage7.Location = new System.Drawing.Point(4, 27);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1257, 643);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Graduate";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // dataGridView17
            // 
            this.dataGridView17.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView17.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11});
            this.dataGridView17.Location = new System.Drawing.Point(87, 377);
            this.dataGridView17.Name = "dataGridView17";
            this.dataGridView17.Size = new System.Drawing.Size(243, 176);
            this.dataGridView17.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.FillWeight = 200F;
            this.dataGridViewTextBoxColumn11.HeaderText = "Concentrations";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 200;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.panel5.Controls.Add(this.dataGridView19);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.richTextBox7);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Location = new System.Drawing.Point(880, 23);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(354, 556);
            this.panel5.TabIndex = 5;
            // 
            // dataGridView19
            // 
            this.dataGridView19.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView19.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13});
            this.dataGridView19.Location = new System.Drawing.Point(58, 354);
            this.dataGridView19.Name = "dataGridView19";
            this.dataGridView19.Size = new System.Drawing.Size(243, 176);
            this.dataGridView19.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.FillWeight = 200F;
            this.dataGridViewTextBoxColumn13.HeaderText = "Concentrations";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Width = 200;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Linen;
            this.label15.Location = new System.Drawing.Point(122, 126);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 25);
            this.label15.TabIndex = 3;
            this.label15.Text = "label15";
            // 
            // richTextBox7
            // 
            this.richTextBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.richTextBox7.Location = new System.Drawing.Point(44, 197);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(280, 151);
            this.richTextBox7.TabIndex = 2;
            this.richTextBox7.Text = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Linen;
            this.label16.Location = new System.Drawing.Point(39, 48);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 16);
            this.label16.TabIndex = 0;
            this.label16.Text = "label16";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(725, 622);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(68, 18);
            this.label31.TabIndex = 8;
            this.label31.Text = "label31";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(279, 622);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(68, 18);
            this.label30.TabIndex = 7;
            this.label30.Text = "label30";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel10.Controls.Add(this.dataGridView18);
            this.panel10.Controls.Add(this.label17);
            this.panel10.Controls.Add(this.richTextBox8);
            this.panel10.Controls.Add(this.label26);
            this.panel10.Location = new System.Drawing.Point(468, 23);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(383, 556);
            this.panel10.TabIndex = 4;
            // 
            // dataGridView18
            // 
            this.dataGridView18.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView18.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12});
            this.dataGridView18.Location = new System.Drawing.Point(64, 354);
            this.dataGridView18.Name = "dataGridView18";
            this.dataGridView18.Size = new System.Drawing.Size(243, 176);
            this.dataGridView18.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.FillWeight = 2000F;
            this.dataGridViewTextBoxColumn12.HeaderText = "Concentrations";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Width = 2000;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Linen;
            this.label17.Location = new System.Drawing.Point(128, 126);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 25);
            this.label17.TabIndex = 2;
            this.label17.Text = "label17";
            // 
            // richTextBox8
            // 
            this.richTextBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.richTextBox8.Location = new System.Drawing.Point(38, 197);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(314, 151);
            this.richTextBox8.TabIndex = 1;
            this.richTextBox8.Text = "";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Linen;
            this.label26.Location = new System.Drawing.Point(33, 48);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(61, 16);
            this.label26.TabIndex = 0;
            this.label26.Text = "label26";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel11.Controls.Add(this.label27);
            this.panel11.Controls.Add(this.richTextBox9);
            this.panel11.Controls.Add(this.label28);
            this.panel11.Location = new System.Drawing.Point(23, 23);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(402, 556);
            this.panel11.TabIndex = 3;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Linen;
            this.label27.Location = new System.Drawing.Point(123, 126);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(96, 25);
            this.label27.TabIndex = 2;
            this.label27.Text = "label27";
            // 
            // richTextBox9
            // 
            this.richTextBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.richTextBox9.Location = new System.Drawing.Point(19, 197);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.Size = new System.Drawing.Size(361, 151);
            this.richTextBox9.TabIndex = 1;
            this.richTextBox9.Text = "";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Linen;
            this.label28.Location = new System.Drawing.Point(46, 55);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(61, 16);
            this.label28.TabIndex = 0;
            this.label28.Text = "label28";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Swis721 Blk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(577, 582);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(96, 25);
            this.label29.TabIndex = 6;
            this.label29.Text = "label29";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // tabPage11
            // 
            this.tabPage11.BackgroundImage = global::IsteWebpage.Properties.Resources.cover51;
            this.tabPage11.Controls.Add(this.panel15);
            this.tabPage11.Controls.Add(this.label21);
            this.tabPage11.Controls.Add(this.panel12);
            this.tabPage11.Controls.Add(this.panel13);
            this.tabPage11.Controls.Add(this.panel14);
            this.tabPage11.Location = new System.Drawing.Point(4, 27);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(1257, 643);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "Degree Statistics";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(179)))), ((int)(((byte)(80)))));
            this.panel15.Controls.Add(this.richTextBox13);
            this.panel15.Controls.Add(this.label22);
            this.panel15.Location = new System.Drawing.Point(958, 113);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(283, 373);
            this.panel15.TabIndex = 7;
            // 
            // richTextBox13
            // 
            this.richTextBox13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox13.Location = new System.Drawing.Point(14, 126);
            this.richTextBox13.Name = "richTextBox13";
            this.richTextBox13.Size = new System.Drawing.Size(248, 226);
            this.richTextBox13.TabIndex = 2;
            this.richTextBox13.Text = "";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Linen;
            this.label22.Location = new System.Drawing.Point(116, 67);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 18);
            this.label22.TabIndex = 0;
            this.label22.Text = "label22";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Swis721 Blk BT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Linen;
            this.label21.Location = new System.Drawing.Point(541, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(110, 29);
            this.label21.TabIndex = 6;
            this.label21.Text = "label21";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(195)))), ((int)(((byte)(163)))));
            this.panel12.Controls.Add(this.richTextBox10);
            this.panel12.Controls.Add(this.label18);
            this.panel12.Location = new System.Drawing.Point(648, 113);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(283, 373);
            this.panel12.TabIndex = 5;
            // 
            // richTextBox10
            // 
            this.richTextBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox10.Location = new System.Drawing.Point(14, 126);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.Size = new System.Drawing.Size(248, 226);
            this.richTextBox10.TabIndex = 2;
            this.richTextBox10.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Linen;
            this.label18.Location = new System.Drawing.Point(69, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 18);
            this.label18.TabIndex = 0;
            this.label18.Text = "label18";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel13.Controls.Add(this.richTextBox11);
            this.panel13.Controls.Add(this.label19);
            this.panel13.Location = new System.Drawing.Point(320, 113);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(301, 373);
            this.panel13.TabIndex = 4;
            this.panel13.Paint += new System.Windows.Forms.PaintEventHandler(this.panel13_Paint);
            // 
            // richTextBox11
            // 
            this.richTextBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox11.Location = new System.Drawing.Point(15, 126);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.Size = new System.Drawing.Size(271, 226);
            this.richTextBox11.TabIndex = 1;
            this.richTextBox11.Text = "";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Linen;
            this.label19.Location = new System.Drawing.Point(116, 67);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 18);
            this.label19.TabIndex = 0;
            this.label19.Text = "label19";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel14.Controls.Add(this.richTextBox12);
            this.panel14.Controls.Add(this.label20);
            this.panel14.Location = new System.Drawing.Point(18, 113);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(273, 373);
            this.panel14.TabIndex = 3;
            // 
            // richTextBox12
            // 
            this.richTextBox12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox12.Location = new System.Drawing.Point(16, 126);
            this.richTextBox12.Name = "richTextBox12";
            this.richTextBox12.Size = new System.Drawing.Size(241, 226);
            this.richTextBox12.TabIndex = 1;
            this.richTextBox12.Text = "";
            this.richTextBox12.TextChanged += new System.EventHandler(this.richTextBox12_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Linen;
            this.label20.Location = new System.Drawing.Point(88, 67);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(68, 18);
            this.label20.TabIndex = 0;
            this.label20.Text = "label20";
            // 
            // tabPage12
            // 
            this.tabPage12.BackgroundImage = global::IsteWebpage.Properties.Resources.current_forms;
            this.tabPage12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage12.Controls.Add(this.panel17);
            this.tabPage12.Controls.Add(this.panel16);
            this.tabPage12.Location = new System.Drawing.Point(4, 27);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(1257, 643);
            this.tabPage12.TabIndex = 3;
            this.tabPage12.Text = "Careers";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panel17.Controls.Add(this.dataGridView5);
            this.panel17.Controls.Add(this.label33);
            this.panel17.Location = new System.Drawing.Point(714, 42);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(413, 422);
            this.panel17.TabIndex = 1;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7});
            this.dataGridView5.Location = new System.Drawing.Point(28, 113);
            this.dataGridView5.MaximumSize = new System.Drawing.Size(800, 800);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 60;
            this.dataGridView5.Size = new System.Drawing.Size(363, 283);
            this.dataGridView5.TabIndex = 1;
            // 
            // Column7
            // 
            this.Column7.FillWeight = 3000F;
            this.Column7.HeaderText = "CareerNames";
            this.Column7.Name = "Column7";
            this.Column7.Width = 3000;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(165, 55);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(68, 18);
            this.label33.TabIndex = 0;
            this.label33.Text = "label33";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(69)))), ((int)(((byte)(65)))));
            this.panel16.Controls.Add(this.dataGridView4);
            this.panel16.Controls.Add(this.label32);
            this.panel16.Location = new System.Drawing.Point(78, 42);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(421, 422);
            this.panel16.TabIndex = 0;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column6});
            this.dataGridView4.Location = new System.Drawing.Point(41, 107);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView4.Size = new System.Drawing.Size(344, 312);
            this.dataGridView4.TabIndex = 1;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            // 
            // Column6
            // 
            this.Column6.FillWeight = 3000F;
            this.Column6.HeaderText = "Employers";
            this.Column6.Name = "Column6";
            this.Column6.Width = 3000;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(136, 55);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(68, 18);
            this.label32.TabIndex = 0;
            this.label32.Text = "label32";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Image = global::IsteWebpage.Properties.Resources.rainbow;
            this.pictureBox2.Location = new System.Drawing.Point(763, 76);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 60);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.UseWaitCursor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabPage1.Font = new System.Drawing.Font("Swis721 Blk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1329, 936);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "About";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Location = new System.Drawing.Point(315, 33);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(696, 526);
            this.panel3.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(17, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(664, 487);
            this.panel2.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Swis721 Blk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Linen;
            this.label4.Location = new System.Drawing.Point(69, 284);
            this.label4.MaximumSize = new System.Drawing.Size(500, 500);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label3.Font = new System.Drawing.Font("Swis721 BlkCn BT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Linen;
            this.label3.Location = new System.Drawing.Point(69, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Swis721 BlkCn BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Linen;
            this.label2.Location = new System.Drawing.Point(154, 405);
            this.label2.MaximumSize = new System.Drawing.Size(500, 500);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(20);
            this.label2.Size = new System.Drawing.Size(99, 62);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Swis721 Blk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Linen;
            this.label1.Location = new System.Drawing.Point(69, 72);
            this.label1.MaximumSize = new System.Drawing.Size(500, 500);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabePage10);
            this.tabControl1.Controls.Add(this.tabPage24);
            this.tabControl1.Controls.Add(this.QuickLinks);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tabControl1.Font = new System.Drawing.Font("Swis721 Blk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(70, 18);
            this.tabControl1.Location = new System.Drawing.Point(13, 141);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1337, 962);
            this.tabControl1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1354, 1020);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.DarkOrange;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "IST Department of RIT";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.QuickLinks.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView58)).EndInit();
            this.tabPage24.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).EndInit();
            this.tabPage26.ResumeLayout(false);
            this.tabPage26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView33)).EndInit();
            this.tabPage27.ResumeLayout(false);
            this.tabPage27.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView52)).EndInit();
            this.tabePage10.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage14.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.tabPage15.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).EndInit();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabControl7.ResumeLayout(false);
            this.tabPage28.ResumeLayout(false);
            this.tabPage28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView53)).EndInit();
            this.tabPage29.ResumeLayout(false);
            this.tabPage29.PerformLayout();
            this.tabControl8.ResumeLayout(false);
            this.tabPage34.ResumeLayout(false);
            this.tabPage34.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView54)).EndInit();
            this.tabPage35.ResumeLayout(false);
            this.tabPage35.PerformLayout();
            this.tabPage36.ResumeLayout(false);
            this.tabPage36.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView55)).EndInit();
            this.tabPage30.ResumeLayout(false);
            this.tabPage30.PerformLayout();
            this.tabPage31.ResumeLayout(false);
            this.tabPage31.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView56)).EndInit();
            this.tabPage32.ResumeLayout(false);
            this.tabPage32.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView57)).EndInit();
            this.tabPage33.ResumeLayout(false);
            this.tabPage33.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.tabPage18.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TabPage QuickLinks;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.RichTextBox richTextBox21;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.DataGridView dataGridView58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.DataGridView dataGridView29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridView dataGridView30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.DataGridView dataGridView31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridView dataGridView32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.DataGridView dataGridView27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridView dataGridView28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.DataGridView dataGridView25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridView dataGridView26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.DataGridView dataGridView23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridView dataGridView24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.DataGridView dataGridView22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridView dataGridView21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.DataGridView dataGridView44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.DataGridView dataGridView43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.DataGridView dataGridView42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.DataGridView dataGridView41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.DataGridView dataGridView40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.DataGridView dataGridView39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.DataGridView dataGridView38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.DataGridView dataGridView37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.DataGridView dataGridView36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.DataGridView dataGridView35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.DataGridView dataGridView34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.DataGridView dataGridView33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.DataGridView dataGridView45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.DataGridView dataGridView46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.DataGridView dataGridView47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.DataGridView dataGridView48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.DataGridView dataGridView49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.DataGridView dataGridView50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.DataGridView dataGridView51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.DataGridView dataGridView52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.TabPage tabePage10;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.RichTextBox richTextBox24;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.RichTextBox richTextBox15;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.RichTextBox richTextBox23;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.RichTextBox richTextBox14;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.RichTextBox richTextBox22;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.RichTextBox richTextBox26;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.RichTextBox richTextBox18;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.RichTextBox richTextBox17;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.RichTextBox richTextBox25;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.RichTextBox richTextBox16;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.RichTextBox richTextBox27;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.DataGridView dataGridView12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.RichTextBox richTextBox20;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.RichTextBox richTextBox28;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.RichTextBox richTextBox19;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.WebBrowser webBrowser2;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabControl tabControl7;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.RichTextBox richTextBox34;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.DataGridView dataGridView53;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.TabPage tabPage29;
        private System.Windows.Forms.TabControl tabControl8;
        private System.Windows.Forms.TabPage tabPage34;
        private System.Windows.Forms.DataGridView dataGridView54;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.TabPage tabPage35;
        private System.Windows.Forms.RichTextBox richTextBox35;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TabPage tabPage36;
        private System.Windows.Forms.DataGridView dataGridView55;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.TabPage tabPage30;
        private System.Windows.Forms.RichTextBox richTextBox36;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.TabPage tabPage31;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.DataGridView dataGridView56;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.TabPage tabPage32;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.DataGridView dataGridView57;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.TabPage tabPage33;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.RichTextBox richTextBox40;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.RichTextBox richTextBox39;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.RichTextBox richTextBox38;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.RichTextBox richTextBox37;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.RichTextBox richTextBox29;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.RichTextBox richTextBox30;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Employer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Degree;
        private System.Windows.Forms.DataGridViewTextBoxColumn City;
        private System.Windows.Forms.DataGridViewTextBoxColumn Term;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DataGridView dataGridView16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView dataGridView15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView dataGridView14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dataGridView17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.DataGridView dataGridView18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RichTextBox richTextBox13;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.RichTextBox richTextBox12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
    }
}


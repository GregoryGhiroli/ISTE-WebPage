﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsteWebpage
{
    public class byInterestArea
    {
        public string areaname { get; set; }
        public  List<string>citations { get; set; }

    }
    public class byFaculty
    {
        public string facultyName { get; set; }
        public string username { get; set; }
        public List<string> citations { get; set; }


    }

    public class Research
    {
        public List<byFaculty> byFaculty{ get; set; }
        public List<byInterestArea> byInterestArea { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsteWebpage
{
   public class Minors
    {

       public List<UgMinors> UgMinors { get; set; }



    }
    public class UgMinors
    {
        public String name { get; set; }
        public String title { get; set; }
        public String description { get; set; }
        public List<String> courses { get; set; }
        public String note { get; set; }


    }
}

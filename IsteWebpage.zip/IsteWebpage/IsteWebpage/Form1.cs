﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IsteWebpage
{
    public partial class Form1 : Form
    {
        //Global Variables
        Employment emp;
        
        Minors minors;
        int timer = 0;
        int next = 0;
        int next2 = 0;
        int next3 = 0;
        int next4 = 0;

        //the other load all the items method, 
        public Form1()
        {
            InitializeComponent();
           
            populate();
           
            peopleLoader();
            peopleLoader2();
           
           
            loadArea();
            loadArea2();
            loadResources();

            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            this.BackColor = Color.Transparent;

        }
        //adds the about data
        private void populate()
        {
            // get About information
            string jsonAbout = getRestData("/about/");

            // need a way to get the JSON form into an About object
            About about = JToken.Parse(jsonAbout).ToObject<About>();

            // start displaying the About object information on the screen
            label3.Text = about.title;
            label1.Text = about.description;
            label4.Text = about.quote;
            label2.Text = about.quoteAuthor;



        }
        //the main constructor, i suppose calls all the loading methods
        private void Form1_Load(object sender, EventArgs e)
        {
            // get About information
            string jsonEmp = getRestData("/employment/");

            // cast it to the object Employment
            emp = JToken.Parse(jsonEmp).ToObject<Employment>();
          
           

            loadTable();
            loadEmploymentTable();
            createJobs();
          
            loadDegree();
            loadMinors();
            loadResources();
            loadFooter();
         


        }
        // uhhhh weird... this was made to load the forms but apparently its somewhere else
        private void loadForms()
        {






        }
        //loads all the resources
        private void loadResources()
        {
          
            string jsonResources = getRestData("/resources/");

            resources res = JToken.Parse(jsonResources).ToObject<resources>();
         



           label130.Text = res.title;
           label131.Text = res.subTitle;

           label133.Text = res.studyAbroad.title;
           richTextBox34.Text = res.studyAbroad.description;

           label132.Text = res.studentServices.title;

           label134.Text = res.studentServices.professonalAdvisors.title;
           label135.Text = res.studentServices.facultyAdvisors.title;
           richTextBox35.Text = res.studentServices.facultyAdvisors.description;

           label137.Text = res.tutorsAndLabInformation.title;
           label138.Text = res.tutorsAndLabInformation.tutoringLabHoursLink;
           richTextBox36.Text = res.tutorsAndLabInformation.description;



           label136.Text = res.studentServices.istMinorAdvising.title;


           label139.Text = res.studentAmbassadors.title;
           label141.Text = res.studentAmbassadors.applicationFormLink;
           label140.Text = res.studentAmbassadors.note;
           pictureBox5.Load(res.studentAmbassadors.ambassadorsImageSource);





           label151.Text = res.coopEnrollment.title;
           label150.Text = res.coopEnrollment.RITJobZoneGuidelink;



           for (int i = 0; i < res.studyAbroad.places.Count; i++)
           {
               dataGridView53.Rows.Add();
               dataGridView53.Rows[i].Cells[0].Value = res.studyAbroad.places[i].nameOfPlace;
               dataGridView53.Rows[i].Cells[1].Value = res.studyAbroad.places[i].description;


           }
           for (int i = 0; i < res.studentServices.professonalAdvisors.advisorInformation.Count; i++)
           {
               dataGridView54.Rows.Add();
               dataGridView54.Rows[i].Cells[0].Value = res.studentServices.professonalAdvisors.advisorInformation[i].name;
               dataGridView54.Rows[i].Cells[1].Value = res.studentServices.professonalAdvisors.advisorInformation[i].department;
               dataGridView54.Rows[i].Cells[2].Value = res.studentServices.professonalAdvisors.advisorInformation[i].email;


           }
           for (int i = 0; i < res.studentServices.istMinorAdvising.minorAdvisorInformation.Count; i++)
           {
               dataGridView55.Rows.Add();
               dataGridView55.Rows[i].Cells[0].Value = res.studentServices.istMinorAdvising.minorAdvisorInformation[i].title;
               dataGridView55.Rows[i].Cells[1].Value = res.studentServices.istMinorAdvising.minorAdvisorInformation[i].advisor;
               dataGridView55.Rows[i].Cells[2].Value = res.studentServices.istMinorAdvising.minorAdvisorInformation[i].email;


           }
           for (int i = 0; i < res.studentAmbassadors.subSectionContent.Count; i++)
           {
               dataGridView56.Rows.Add();
               dataGridView56.Rows[i].Cells[0].Value = res.studentAmbassadors.subSectionContent[i].title;
               dataGridView56.Rows[i].Cells[1].Value = res.studentAmbassadors.subSectionContent[i].description;


           }
           for (int i = 0; i < res.forms.graduateForms.Count; i++)
           {
               dataGridView57.Rows.Add();
               dataGridView57.Rows[i].Cells[0].Value = res.forms.graduateForms[i].formName;
               dataGridView57.Rows[i].Cells[1].Value = res.forms.graduateForms[i].href;

           


               
           }
           for (int i = 0; i < res.forms.undergraduateForms.Count; i++)
           {


               label142.Text = res.forms.undergraduateForms[i].formName;

               label143.Text = res.forms.undergraduateForms[i].href;




           }

           int countenroll = 0;
           foreach (enrollmentInformationContent eic in res.coopEnrollment.enrollmentInformationContent)
            {

                if (countenroll == 0)
                {

                    label146.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].title;
                    richTextBox37.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].description;

                }
                if (countenroll == 1)
                {

                    label147.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].title;
                    richTextBox38.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].description;

                }
                if (countenroll == 2)
                {

                    label148.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].title;
                    richTextBox39.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].description;

                }
                if (countenroll == 3)
                {

                    label149.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].title;
                    richTextBox40.Text = res.coopEnrollment.enrollmentInformationContent[countenroll].description;

                }
                countenroll++;
            }
        }
        //loads the footer
        private void loadFooter()
        {

            string jsonFoot = getRestData("/footer/");

          
            Footer foot = JToken.Parse(jsonFoot).ToObject<Footer>();

            label152.Text = foot.social.title;
            label153.Text = foot.social.tweet;
            label154.Text = foot.social.by;
            label155.Text = foot.social.twitter;
            label156.Text = foot.social.facebook;
            label157.Text = foot.copyright.title;
            richTextBox21.Text = foot.copyright.html;
            label50.Text = foot.news;

            for (int i = 0; i < foot.quickLinks.Count; i++)
            {


                dataGridView58.Rows.Add();
                dataGridView58.Rows[i].Cells[0].Value = foot.quickLinks[i].title;

               dataGridView58.Rows[i].Cells[1].Value = foot.quickLinks[i].href;




            }

        }
        //load the minors
        private void loadMinors()
        {
          
           // get minor information
            string jsonMinors = getRestData("/minors/");

            // cast it to the object minor
            minors = JToken.Parse(jsonMinors).ToObject<Minors>();

            int underMinor = 0;

            foreach (UgMinors ug in minors.UgMinors)
            {

                if(underMinor == 0)
                {

                    label48.Text = ug.name;
                    label47.Text = ug.title;
                    richTextBox20.Text = ug.description;
                    richTextBox27.Text = ug.note;
                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView3.Rows.Add();
                        dataGridView3.Rows[i].Cells[0].Value = ug.courses[i];

                    }
                                      

                }
                else if(underMinor == 1)
                {
                    label46.Text = ug.name;
                    label45.Text = ug.title;
                    richTextBox19.Text = ug.description;
                    richTextBox28.Text = ug.note;
                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView6.Rows.Add();
                        dataGridView6.Rows[i].Cells[0].Value = ug.courses[i];

                    }


                }
                else if (underMinor == 2)
                {
                    label40.Text = ug.name;
                    label39.Text = ug.title;
                    richTextBox16.Text = ug.description;
                    richTextBox25.Text = ug.note; 
                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView7.Rows.Add();
                        dataGridView7.Rows[i].Cells[0].Value = ug.courses[i];

                    }


                }
                else if (underMinor == 3)
                {
                    label42.Text = ug.name;
                    label41.Text = ug.title;
                    richTextBox17.Text = ug.description;
                   
                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView8.Rows.Add();
                        dataGridView8.Rows[i].Cells[0].Value = ug.courses[i];

                    }


                }
                else if (underMinor == 4)
                {
                    label44.Text = ug.name;
                    label43.Text = ug.title;
                    richTextBox18.Text = ug.description;
                    richTextBox26.Text = ug.note;
                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView9.Rows.Add();
                        dataGridView9.Rows[i].Cells[0].Value = ug.courses[i];

                    }


                }
                else if (underMinor == 5)
                {
                    label8.Text = ug.name;
                    label34.Text = ug.title;
                    richTextBox1.Text = ug.description;
                    richTextBox22.Text = ug.note;
                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView10.Rows.Add();
                        dataGridView10.Rows[i].Cells[0].Value = ug.courses[i];

                    }


                }
                else if (underMinor == 6)
                {
                    label36.Text = ug.name;
                    label35.Text = ug.title;
                    richTextBox14.Text = ug.description;
                    richTextBox23.Text = ug.note;

                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView12.Rows.Add();
                        dataGridView12.Rows[i].Cells[0].Value = ug.courses[i];

                    }


                }
                else if (underMinor == 7)
                {
                    label38.Text = ug.name;
                    label37.Text = ug.title;
                    richTextBox15.Text = ug.description;
                    richTextBox24.Text = ug.note;
                    for (int i = 0; i < ug.courses.Count; i++)
                    {
                        dataGridView11.Rows.Add();
                        dataGridView11.Rows[i].Cells[0].Value = ug.courses[i];

                    }

                }

                underMinor++;


            }
            



        }
        // create the jobs from employment
        private void createJobs()
        {

            label12.Text = emp.introduction.title;

            int i = 0;
            foreach( Content thiscon in emp.introduction.content)
            {
                if (i == 0)
                {

                    label13.Text = thiscon.title;
                    richTextBox5.Text = thiscon.description;
                }
                else
                {
                    label14.Text = thiscon.title;
                    richTextBox6.Text = thiscon.description;
                }
                i++;

            }

            int j = 0;

            label21.Text = emp.degreeStatistics.title;

            foreach(Statistic thisstat in emp.degreeStatistics.statistics)
            {
                if( j == 0)
                {
                    label20.Text = thisstat.value;
                    richTextBox12.Text = thisstat.description;


                }
                else if(j ==1)
                {

                    label19.Text = thisstat.value;
                    richTextBox11.Text = thisstat.description;


                }
                else if (j ==2)
                {

                    label22.Text = thisstat.value;
                    richTextBox13.Text = thisstat.description;


                }

                else
                {

                    label18.Text = thisstat.value;
                    richTextBox10.Text = thisstat.description;


                }
                j++;
            }
            label32.Text = emp.employers.title;
            label33.Text = emp.careers.title;


            for (var employerCount = 0; employerCount < emp.employers.employerNames.Count; employerCount++)
            {

              
                
                
                
                
                dataGridView4.Rows.Add();
                dataGridView4.Rows[employerCount].Cells[0].Value =
                    emp.employers.employerNames[employerCount];
                

            }
            for (var careerCount = 0; careerCount < emp.careers.careerNames.Count; careerCount++)
            {






                dataGridView5.Rows.Add();
                dataGridView5.Rows[careerCount].Cells[0].Value =
                    emp.careers.careerNames[careerCount];


            }



        }

       
        //self explainitory
        public void createMap()
        {



            webBrowser1.Navigate("http://ist.rit.edu/api/map");


        }
     
        #region getRestData - Returns the requested API information as a string
        private string getRestData(string url)
        {
            string baseUri = "http://ist.rit.edu/api";

            // connect to the API
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUri + url);
            try
            {
                WebResponse response = request.GetResponse();

                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    return reader.ReadToEnd();
                }
            }
            catch (WebException we)
            {
                // Something goes wrong, get the error response, then do something with it
                WebResponse err = we.Response;
                using (Stream responseStream = err.GetResponseStream())
                {
                    StreamReader r = new StreamReader(responseStream, Encoding.UTF8);
                    string errorText = r.ReadToEnd();
                    // display or log error
                    Console.WriteLine(errorText);
                }
                throw;
            }
        } // end getRestData
        #endregion




        //Ignore this
        private void tabPage3_Click(object sender, EventArgs e)
        {
        


        }
        //loads the coptable
        private void loadTable()
        {
            label5.Text = emp.coopTable.title;

            for (var i = 0; i < emp.coopTable.coopInformation.Count; i++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value =
                    emp.coopTable.coopInformation[i].employer;
                dataGridView1.Rows[i].Cells[1].Value =
                    emp.coopTable.coopInformation[i].degree;
                dataGridView1.Rows[i].Cells[2].Value =
                    emp.coopTable.coopInformation[i].city;
                dataGridView1.Rows[i].Cells[3].Value =
                    emp.coopTable.coopInformation[i].term;
            }


        }
        //loads the employmenttable
        private void loadEmploymentTable()
        {
            label7.Text = emp.employmentTable.title;
            for (var i = 0; i < emp.employmentTable.professionalEmploymentInformation.Count; i++)
            {
                dataGridView2.Rows.Add();
                dataGridView2.Rows[i].Cells[0].Value =
                    emp.employmentTable.professionalEmploymentInformation[i].employer;
                dataGridView2.Rows[i].Cells[1].Value =
                    emp.employmentTable.professionalEmploymentInformation[i].degree;
                dataGridView2.Rows[i].Cells[2].Value =
                    emp.employmentTable.professionalEmploymentInformation[i].city;
                dataGridView2.Rows[i].Cells[3].Value =
                    emp.employmentTable.professionalEmploymentInformation[i].title;
                dataGridView2.Rows[i].Cells[4].Value =
                   emp.employmentTable.professionalEmploymentInformation[i].startDate;


            }



        }
        //loads the degrees
        private void loadDegree()
        {

            // get Degrees information
            string jsonDegrees = getRestData("/degrees/");

            // need a way to get the JSON form into an Degrees object
            Degrees degrees = JToken.Parse(jsonDegrees).ToObject<Degrees>();
            

           // MessageBox.Show(degrees.Undergraduate.title + "work");

            int underCount = 0;
            int gradCount = 0;
            //undergrad stuff
            foreach (undergraduate ud in degrees.undergraduate)
            {
                if (underCount == 0)
                {
                    label9.Text = ud.title;
                    label23.Text = ud.degreeName;
                    richTextBox2.Text = ud.description;
                    for(int i = 0; i <ud.concentrations.Count ; i ++)
                    {
                        dataGridView14.Rows.Add();
                        dataGridView14.Rows[i].Cells[0].Value = ud.concentrations[i];

                    }
                }
                 else if (underCount == 1)
                {
                    label10.Text = ud.title;
                    label24.Text = ud.degreeName;
                    richTextBox3.Text = ud.description;

                    for (int i = 0; i < ud.concentrations.Count; i++)
                    {
                        dataGridView15.Rows.Add();
                        dataGridView15.Rows[i].Cells[0].Value = ud.concentrations[i];

                    }

                }
                else if( underCount == 2)
                {
                    label11.Text = ud.title;
                    label25.Text = ud.degreeName;
                    richTextBox4.Text = ud.description;
                    for (int i = 0; i < ud.concentrations.Count; i++)
                    {
                        dataGridView16.Rows.Add();
                        dataGridView16.Rows[i].Cells[0].Value = ud.concentrations[i];

                    }

                }
                underCount++;

            }
            //grad stuff
            foreach (graduate ud in degrees.graduate)
            {
                if (gradCount == 0)
                {
                    label28.Text = ud.title;
                    label27.Text = ud.degreeName;
                    richTextBox9.Text = ud.description;
                    for (int i = 0; i < ud.concentrations.Count; i++)
                    {
                        dataGridView17.Rows.Add();
                        dataGridView17.Rows[i].Cells[0].Value = ud.concentrations[i];

                    }

                }
                else if (gradCount == 1)
                {
                    label26.Text = ud.title;
                    label17.Text = ud.degreeName;
                    richTextBox8.Text = ud.description;


                    for (int i = 0; i < ud.concentrations.Count; i++)
                    {
                        dataGridView18.Rows.Add();
                        dataGridView18.Rows[i].Cells[0].Value = ud.concentrations[i];

                    }

                }
                else if (gradCount == 2)
                {
                    label16.Text = ud.title;
                    label15.Text = ud.degreeName;
                    richTextBox7.Text = ud.description;

                    for (int i = 0; i < ud.concentrations.Count; i++)
                    {
                        dataGridView19.Rows.Add();
                        dataGridView19.Rows[i].Cells[0].Value = ud.concentrations[i];

                    }

                }
                else
                {
                    label29.Text = ud.degreeName;

                  

                        label30.Text = ud.availableCertificates[0];
                        label31.Text = ud.availableCertificates[1];

                      


                    
                  

                }
                gradCount++;

            }



        }
    
        //Oh ignore all of these this was just me accidentally double clicking things

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void aboutDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void tabPage6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
           
        }
        //This is the button for creating the map actually important unlike everything else around it
        private void button1_Click(object sender, EventArgs e)
        {
            createMap();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage7_Click(object sender, EventArgs e)
        {

        }

        private void webBrowser2_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void tabPage8_Click(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox24_TextChanged(object sender, EventArgs e)
        {

        }
        //ok back to important stuff, this controls the counter than tells which person shows up, goes backwards
        private void button2_Click(object sender, EventArgs e)
        {
            if( next != 0)
            {

                next --;

            }
            peopleLoader();
        }

        //loads the people from faculty, controlled by other buttoms
        private void peopleLoader()
        {
            Console.Write(next);
             // get the JSON for people
            string jsonPeople = getRestData("/people/");
            int changer = 0;
            // cast it to a People object 
            People people = JToken.Parse(jsonPeople).ToObject<People>();

            foreach (Faculty thisFac in people.faculty)
            {
                Console.Write(changer);
                // Console.WriteLine(thisFac.name); 
                // Uncomment to see all faculty
                if (changer == 0 && next == 0)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 1 && next == 1)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 2 && next == 2)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 3 && next == 3)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 4 && next == 4)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 5 && next == 5)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 6 && next == 6)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 7 && next == 7)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 8 && next == 8)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 9 && next == 9)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 10 && next == 10)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 11 && next == 11)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown

                }
                if (changer == 12 && next == 12)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 13 && next == 13)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown

                }
                if (changer == 14 && next == 14)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 15 && next == 15)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 16 && next == 16)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 17 && next == 17)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 18 && next == 18)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 19 && next == 19)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 20 && next == 20)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 21 && next == 21)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 22 && next == 22)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 23 && next == 23)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 24 && next == 24)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 25 && next == 25)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 26 && next == 26)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 27 && next == 27)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 28 && next == 28)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 29 && next == 29)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 30 && next == 30)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 31 && next == 31)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 32 && next == 32)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 33 && next == 33)
                {
                    label51.Text = thisFac.name;
                    label52.Text = thisFac.title;
                    label58.Text = thisFac.tagline;
                    label53.Text = thisFac.office;
                    label54.Text = thisFac.website;
                    label55.Text = thisFac.phone;
                    label56.Text = thisFac.email;
                    label57.Text = thisFac.twitter;
                    label59.Text = thisFac.facebook;
                    richTextBox29.Text = thisFac.interestArea;
                    label60.Text = thisFac.username;
                    pictureBox12.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                changer++;
            }





        }
            
           
        //button that makes the faculty go forward, next person i guess
        private void button3_Click(object sender, EventArgs e)
        {
            if(next != 33)
            {
            next++;
            peopleLoader();
            }
        }
        //this button is backwards for the person in staff ( people loader2)
        private void button5_Click(object sender, EventArgs e)
        {
            if (next2 != 0)
            {

                next2--;

            }
            peopleLoader2();
        }

    //this button is forward for the person in staff (load loader2)
        private void button4_Click(object sender, EventArgs e)
        {
            if (next2 != 13)
            {
                next2++;
                peopleLoader2();
            }
        }
        //loads the people from staff, same as people loader()
        private void peopleLoader2()
        {
            Console.Write(next);
            // get the JSON for people
            string jsonPeople = getRestData("/people/");
            int changer = 0;
            // cast it to a People object 
            People people = JToken.Parse(jsonPeople).ToObject<People>();

            foreach (Staff thisFac in people.staff)
            {
                Console.Write(changer);
                // Console.WriteLine(thisFac.name); 
                // Uncomment to see all faculty
                if (changer == 0 && next2 == 0)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 1 && next2 == 1)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 2 && next2 == 2)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 3 && next2 == 3)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 4 && next2 == 4)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 5 && next2 == 5)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 6 && next2 == 6)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 7 && next2 == 7)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 8 && next2 == 8)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 9 && next2 == 9)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 10 && next2 == 10)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 11 && next2 == 11)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 12 && next2 == 12)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }
                if (changer == 13 && next2 == 13)
                {
                    label64.Text = thisFac.name;
                    label63.Text = thisFac.title;
                    label68.Text = thisFac.tagline;
                    label62.Text = thisFac.office;
                    label65.Text = thisFac.website;
                    label66.Text = thisFac.phone;
                    label67.Text = thisFac.email;
                    label68.Text = thisFac.twitter;
                    label70.Text = thisFac.facebook;
                    richTextBox30.Text = thisFac.interestArea;
                    label61.Text = thisFac.username;
                    pictureBox4.Load(thisFac.imagePath);    // Shows all pictures, but only last is shown
                }




                changer++;

            }
        }
   

     
       
        //load the research stuff
        private void loadArea()
        {
         
            string jsonResearch = getRestData("/research/");

           int nextcit = 0;
           
            Research re = JToken.Parse(jsonResearch).ToObject<Research>();

        
            foreach( byInterestArea byi in re.byInterestArea)
            {
                if( nextcit == 0)
                {
  
                    label77.Text = byi.areaname;

                    for(var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView21.Rows.Add();
                        dataGridView21.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 1)
                {

                    label79.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView22.Rows.Add();
                        dataGridView22.Rows[i].Cells[0].Value =
                            byi.citations[i];

                        Console.Write(byi.citations.Count + "how many cits");
                    }


                }
                if (nextcit == 2)
                {

                    label80.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView23.Rows.Add();
                        dataGridView23.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 3)
                {

                    label81.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView24.Rows.Add();
                        dataGridView24.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 4)
                {

                    label82.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView25.Rows.Add();
                        dataGridView25.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 5)
                {

                    label83.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView26.Rows.Add();
                        dataGridView26.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 6)
                {

                    label84.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView27.Rows.Add();
                        dataGridView27.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 7)
                {

                    label85.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView28.Rows.Add();
                        dataGridView28.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 8)
                {

                    label86.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView29.Rows.Add();
                        dataGridView29.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 9)
                {

                    label87.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView30.Rows.Add();
                        dataGridView30.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 10)
                {

                    label88.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView31.Rows.Add();
                        dataGridView31.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
                if (nextcit == 11)
                {

                    label89.Text = byi.areaname;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView32.Rows.Add();
                        dataGridView32.Rows[i].Cells[0].Value =
                            byi.citations[i];


                    }


                }
             
                nextcit ++;
            }
          
          


        }
        //loads the faculty research
        private void loadArea2()
        {

            string jsonResearch = getRestData("/research/");

            int nextcit = 0;

            Research re = JToken.Parse(jsonResearch).ToObject<Research>();


            foreach (byFaculty byi in re.byFaculty)
            {
                if (nextcit == 0)
                {

                    label90.Text =byi.facultyName;
                    label91.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView33.Rows.Add();
                        dataGridView33.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 1)
                {

                    label93.Text = byi.facultyName;
                    label92.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView34.Rows.Add();
                        dataGridView34.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 2)
                {

                    label95.Text = byi.facultyName;
                    label94.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView35.Rows.Add();
                        dataGridView35.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 3)
                {

                    label97.Text = byi.facultyName;
                    label96.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView36.Rows.Add();
                        dataGridView36.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 4)
                {

                    label99.Text = byi.facultyName;
                    label98.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView37.Rows.Add();
                        dataGridView37.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 5)
                {

                    label101.Text = byi.facultyName;
                    label100.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView38.Rows.Add();
                        dataGridView38.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 6)
                {

                    label103.Text = byi.facultyName;
                    label102.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView39.Rows.Add();
                        dataGridView39.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 7)
                {

                    label105.Text = byi.facultyName;
                    label104.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView40.Rows.Add();
                        dataGridView40.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 8)
                {

                    label107.Text = byi.facultyName;
                    label106.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView41.Rows.Add();
                        dataGridView41.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 9)
                {

                    label109.Text = byi.facultyName;
                    label108.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView42.Rows.Add();
                        dataGridView42.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 10)
                {

                    label111.Text = byi.facultyName;
                    label110.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView43.Rows.Add();
                        dataGridView43.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 11)
                {

                    label113.Text = byi.facultyName;
                    label112.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView44.Rows.Add();
                        dataGridView44.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 12)
                {

                    label115.Text = byi.facultyName;
                    label114.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView45.Rows.Add();
                        dataGridView45.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 13)
                {

                    label117.Text = byi.facultyName;
                    label116.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView46.Rows.Add();
                        dataGridView46.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 14)
                {

                    label119.Text = byi.facultyName;
                    label118.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView47.Rows.Add();
                        dataGridView47.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 15)
                {

                    label121.Text = byi.facultyName;
                    label120.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView48.Rows.Add();
                        dataGridView48.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 16)
                {

                    label123.Text = byi.facultyName;
                    label122.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView49.Rows.Add();
                        dataGridView49.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 17)
                {

                    label125.Text = byi.facultyName;
                    label124.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView50.Rows.Add();
                        dataGridView50.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 18)
                {

                    label127.Text = byi.facultyName;
                    label126.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView51.Rows.Add();
                        dataGridView51.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
                if (nextcit == 19)
                {

                    label129.Text = byi.facultyName;
                    label128.Text = byi.username;

                    for (var i = 0; i < byi.citations.Count; i++)
                    {
                        dataGridView52.Rows.Add();
                        dataGridView52.Rows[i].Cells[0].Value =
                            byi.citations[i];
                    }


                }
               
                nextcit++;
            }

        }
        //loads quarter news
        private void loadQuarter()
        {


            // get Degrees information
            string jsonNews = getRestData("/news/");

            // need a way to get the JSON form into an Degrees object
            News news = JToken.Parse(jsonNews).ToObject<News>();
            // degrees = JToken.Parse(jsonDegrees).ToObject<Degrees>();
         
            // MessageBox.Show(degrees.Undergraduate.title + "work");
/*
            foreach (quarter q in news.quarter)
            {
                if (news.quarter != null)
                {
                    if (changer == 0 && next4 == 0)
                    {
                        label74.Text = q.date;
                        label73.Text = q.title;
                        richTextBox32.Text = q.description;

                    }
                    if (changer == 1 && next4 == 1)
                    {
                        label74.Text = q.date;
                        label73.Text = q.title;
                        richTextBox32.Text = q.description;
                    }
                    if (changer == 2 && next4 == 2)
                    {
                        label74.Text = q.date;
                        label73.Text = q.title;
                        richTextBox32.Text = q.description;
                    }
                    if (changer == 3 && next4 == 3)
                    {
                        label74.Text = q.date;
                        label73.Text = q.title;
                        richTextBox32.Text = q.description;
                    }
                    changer++;
                }
                else
                {

                    return;
                }
            }
 * */
           
        }
        //controls quater news
        private void button8_Click(object sender, EventArgs e)
        {
            if (next4 != 0)
            {

                next4--;
                loadQuarter();

            }
        }
        //controls quarter news
        private void button9_Click(object sender, EventArgs e)
        {
            if (next4 != 3)
            {

                next4++;
                loadQuarter();

            }
        }
        //loads month
        private void loadMonth()
        {


            // get Degrees information
            string jsonNews = getRestData("/news/");

            // need a way to get the JSON form into an Degrees object
            News news = JToken.Parse(jsonNews).ToObject<News>();
            // degrees = JToken.Parse(jsonDegrees).ToObject<Degrees>();
         
            // MessageBox.Show(degrees.Undergraduate.title + "work");
        /*
            foreach (month q in news.month)
            {
                
                    label76.Text = q.date;
                    label75.Text = q.title;
                    richTextBox33.Text = q.description;

                
            }
         * */
        }
        //ignore these i double clicked again, i could get rid of them but they can cause the project to crash if i'm not careful so i'm not risking it
        private void dataGridView21_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView22_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage33_Click(object sender, EventArgs e)
        {

        }

        private void label157_Click(object sender, EventArgs e)
        {

        }

        private void label153_Click(object sender, EventArgs e)
        {

        }
    }//end of something important
    }//end of everything

